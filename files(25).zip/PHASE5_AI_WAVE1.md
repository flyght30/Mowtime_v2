# Phase 5: AI Wave 1

**Duration:** 4 weeks
**Prerequisites:** Phase 4 complete
**Goal:** Voice receptionist, voice notes, smart dispatch

---

## 5.1 Goals

By end of Phase 5, contractors can:
- Have AI receptionist answer calls 24/7
- AI books appointments and answers status questions
- Techs record voice notes that become written summaries
- Dispatch gets AI-powered tech recommendations
- No-show prediction flags high-risk appointments

---

## 5.2 Features

### AI Voice Receptionist

**Capabilities:**
- Answer incoming calls with company greeting
- New customer intake (name, phone, address, issue)
- Schedule appointments based on availability
- Answer "where's my tech?" questions
- Handle reschedule/cancel requests
- Transfer to human for complex issues
- After-hours message taking

**Voice:** ElevenLabs conversational AI
**Telephony:** Twilio Voice
**Logic:** Claude API for conversation handling

### Voice Notes → Summary

**Flow:**
1. Tech taps "Voice Note" on completion
2. Records description of work done
3. Audio sent to Whisper API for transcription
4. Transcription sent to Claude for professional summary
5. Summary populates completion notes field
6. Tech reviews/edits before submitting

### Smart Dispatch

**Factors for tech recommendation:**
- Distance from job site (weighted heavily)
- Current workload and availability
- Skill match (install vs service)
- Historical performance with job type
- Customer history (same tech preference)
- Traffic conditions

**Output:**
- Ranked list of recommended techs
- Score and reasoning for each
- One-click assign best match

### No-Show Prediction

**Signals:**
- Previous no-shows
- Time since last contact
- Appointment lead time
- SMS engagement (replies?)
- Day of week patterns

**Actions:**
- Flag high-risk appointments
- Suggest confirmation call
- Priority for reminder SMS

---

## 5.3 Database Models

### VoiceCall
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "customer_id": ObjectId | None,
  "job_id": ObjectId | None,
  
  "direction": "inbound" | "outbound",
  "from_phone": str,
  "to_phone": str,
  
  "twilio_call_sid": str,
  "status": "ringing" | "in_progress" | "completed" | "failed" | "no_answer",
  "duration_seconds": int,
  
  "handled_by": "ai" | "human" | "voicemail",
  "ai_outcome": "appointment_booked" | "status_inquiry" | "reschedule" | "cancel" | "transfer" | "message" | None,
  
  "transcript": str | None,
  "summary": str | None,
  
  "recording_url": str | None,
  "created_at": datetime,
  "ended_at": datetime | None
}
```

### VoiceNote
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "job_id": ObjectId,
  "tech_id": ObjectId,
  
  "audio_url": str,
  "duration_seconds": int,
  
  "transcription": str | None,
  "summary": str | None,
  
  "status": "uploaded" | "transcribing" | "summarizing" | "complete" | "failed",
  "error": str | None,
  
  "created_at": datetime,
  "processed_at": datetime | None
}
```

### DispatchSuggestion
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "job_id": ObjectId,
  
  "suggestions": [
    {
      "tech_id": ObjectId,
      "score": int,              # 0-100
      "distance_miles": float,
      "eta_minutes": int,
      "availability_start": str,
      "reasons": [str]
    }
  ],
  
  "factors_used": {
    "distance_weight": float,
    "skill_weight": float,
    "workload_weight": float
  },
  
  "created_at": datetime,
  "accepted_tech_id": ObjectId | None
}
```

---

## 5.4 API Endpoints

### Voice Receptionist

```
POST /api/v1/voice/webhook/incoming
# Twilio webhook for incoming calls
Request: Twilio call webhook payload
Response: TwiML to start AI conversation

POST /api/v1/voice/webhook/status
# Call status updates
Request: Twilio status callback
Response: 200 OK

POST /api/v1/voice/conversation
# AI conversation turn
Request: {
  "call_sid": "CA...",
  "speech_result": "I need to schedule an AC installation",
  "conversation_history": [...]
}
Response: {
  "response_text": "I'd be happy to help schedule that...",
  "action": "continue" | "transfer" | "end",
  "data_collected": { "name": "John", "issue": "AC install" }
}

GET /api/v1/voice/calls
Query: ?date=2025-01-22&handled_by=ai
Response: List of calls with outcomes

GET /api/v1/voice/calls/{call_sid}
Response: Full call details with transcript
```

### Voice Notes

```
POST /api/v1/voice-notes/upload
Request: multipart/form-data with audio file
Response: {
  "id": "...",
  "status": "uploaded",
  "duration_seconds": 45
}

GET /api/v1/voice-notes/{id}
Response: Voice note with transcription and summary

POST /api/v1/voice-notes/{id}/process
# Trigger transcription + summarization
Response: {
  "status": "transcribing"
}

# WebSocket updates for processing status
```

### Smart Dispatch

```
POST /api/v1/dispatch/suggest
Request: {
  "job_id": "..."
}
Response: {
  "suggestions": [
    {
      "tech_id": "...",
      "tech_name": "Mike Johnson",
      "score": 92,
      "distance_miles": 3.2,
      "eta_minutes": 8,
      "availability": "Now - 5:00 PM",
      "reasons": [
        "Closest available tech (3.2 mi)",
        "Install certified",
        "92% on-time rate for installs"
      ]
    }
  ]
}

POST /api/v1/dispatch/suggest/{job_id}/accept
Request: {
  "tech_id": "...",
  "scheduled_time": "14:00"
}
Response: Updated job with assignment
```

### No-Show Prediction

```
GET /api/v1/jobs/{id}/no-show-risk
Response: {
  "risk_score": 0.35,
  "risk_level": "medium",
  "factors": [
    { "factor": "no_sms_reply", "impact": 0.15 },
    { "factor": "first_time_customer", "impact": 0.10 },
    { "factor": "monday_morning", "impact": 0.10 }
  ],
  "recommendation": "Send confirmation SMS"
}

GET /api/v1/schedule/at-risk
Query: ?date=2025-01-22&threshold=0.3
Response: List of high-risk appointments
```

---

## 5.5 Wireframes

### Voice Call Log
```
┌────────────────────────────────────────────────────────────────────────┐
│  Voice Calls                                         Jan 22, 2025     │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  [All] [AI Handled] [Transferred] [Missed]            🔍 Search       │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ 📞 Incoming • 10:32 AM                           Duration: 2:45│   │
│  │ (555) 123-4567 → New Customer                                  │   │
│  │                                                                │   │
│  │ 🤖 AI Handled: Appointment Booked                              │   │
│  │ "Scheduled AC installation for John Smith, Jan 24 at 9 AM"     │   │
│  │                                                                │   │
│  │ [View Transcript] [Listen] [View Job]                          │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ 📞 Incoming • 9:15 AM                            Duration: 1:30│   │
│  │ (555) 987-6543 → Mary Jones                                    │   │
│  │                                                                │   │
│  │ 🤖 AI Handled: Status Inquiry                                  │   │
│  │ "Provided ETA for technician arrival"                          │   │
│  │                                                                │   │
│  │ [View Transcript] [Listen]                                     │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ 📞 Incoming • 8:45 AM                            Duration: 0:45│   │
│  │ (555) 555-0100 → Unknown                                       │   │
│  │                                                                │   │
│  │ 👤 Transferred to Office                                       │   │
│  │ "Customer requested to speak with owner about pricing"         │   │
│  │                                                                │   │
│  │ [View Transcript] [Listen]                                     │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Call Transcript View
```
┌─────────────────────────────────────────────────────────────────┐
│  Call Transcript                                         [✕]    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  (555) 123-4567 • Jan 22, 10:32 AM • 2:45                      │
│  Outcome: Appointment Booked                                    │
│                                                                 │
│  ─────────────────────────────────────────────────────────────  │
│                                                                 │
│  🤖 AI: "Thank you for calling ABC Heating and Air. This       │
│      is Clara, your virtual assistant. How can I help you      │
│      today?"                                                    │
│                                                                 │
│  👤 Caller: "Hi, I need to get a new AC unit installed."       │
│                                                                 │
│  🤖 AI: "I'd be happy to help you schedule an AC               │
│      installation. Can I get your name please?"                 │
│                                                                 │
│  👤 Caller: "John Smith"                                        │
│                                                                 │
│  🤖 AI: "Thank you John. And what's the best phone number      │
│      to reach you?"                                             │
│                                                                 │
│  👤 Caller: "555-123-4567"                                      │
│                                                                 │
│  🤖 AI: "Got it. And what's your address?"                     │
│                                                                 │
│  👤 Caller: "123 Main Street, Auburn Alabama"                   │
│                                                                 │
│  🤖 AI: "Perfect. I have availability on Thursday January      │
│      24th at 9 AM or Friday the 25th at 2 PM. Which works      │
│      better for you?"                                           │
│                                                                 │
│  👤 Caller: "Thursday morning works"                            │
│                                                                 │
│  🤖 AI: "Excellent! I've scheduled your AC installation for    │
│      Thursday January 24th at 9 AM. You'll receive a text      │
│      confirmation shortly. Is there anything else I can        │
│      help you with?"                                            │
│                                                                 │
│  👤 Caller: "No that's it, thanks"                              │
│                                                                 │
│  🤖 AI: "Thank you for choosing ABC Heating and Air. Have      │
│      a great day!"                                              │
│                                                                 │
│  ─────────────────────────────────────────────────────────────  │
│                                                                 │
│  Data Collected                                                 │
│  Name: John Smith                                               │
│  Phone: (555) 123-4567                                          │
│  Address: 123 Main Street, Auburn, AL                           │
│  Service: AC Installation                                       │
│  Scheduled: Jan 24, 2025 at 9:00 AM                            │
│                                                                 │
│  [🔊 Play Recording]           [View Created Job]               │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Smart Dispatch Suggestions
```
┌─────────────────────────────────────────────────────────────────┐
│  Assign Job                                              [✕]    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  JOB-2025-0045 • John Smith • Install 3.5T                     │
│  123 Main Street, Auburn, AL                                    │
│                                                                 │
│  ═══════════════════════════════════════════════════════════   │
│                                                                 │
│  🤖 AI Recommendations                                          │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ ⭐ #1 Mike Johnson                          Score: 92   │   │
│  │                                                         │   │
│  │ ✓ Closest available (3.2 mi, 8 min)                    │   │
│  │ ✓ Install certified (NATE)                              │   │
│  │ ✓ 94% on-time rate for installs                        │   │
│  │ ✓ Available now until 5:00 PM                          │   │
│  │                                                         │   │
│  │              [Assign Mike → 2:00 PM]                    │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ #2 Tom Baker                                Score: 78   │   │
│  │                                                         │   │
│  │ ✓ Available all day                                     │   │
│  │ ✓ Install certified                                     │   │
│  │ ○ Further away (8.5 mi, 22 min)                        │   │
│  │                                                         │   │
│  │              [Assign Tom]                               │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ #3 Sarah Kim                                Score: 65   │   │
│  │                                                         │   │
│  │ ✓ Close by (4.1 mi, 12 min)                            │   │
│  │ ○ On job until 4:00 PM                                  │   │
│  │ ○ Primarily service tech                                │   │
│  │                                                         │   │
│  │              [Assign Sarah → 4:00 PM]                   │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  [Manual Assignment ▼]                                          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Voice Note (Mobile)
```
┌─────────────────────────────────┐
│ ← Back              Voice Note  │
├─────────────────────────────────┤
│                                 │
│                                 │
│         ┌───────────┐           │
│         │           │           │
│         │    🎤     │           │
│         │           │           │
│         │  0:32     │           │
│         │           │           │
│         └───────────┘           │
│                                 │
│      Recording...               │
│                                 │
│      [ ⬛ Stop ]                │
│                                 │
│  ─────────────────────────────  │
│                                 │
│  Tips:                          │
│  • Describe work performed      │
│  • Mention any issues found     │
│  • Note parts/materials used    │
│  • Include customer feedback    │
│                                 │
└─────────────────────────────────┘

        ↓ After processing ↓

┌─────────────────────────────────┐
│ ← Back              Voice Note  │
├─────────────────────────────────┤
│                                 │
│  ✓ Transcribed & Summarized     │
│                                 │
│  Original (0:32)      [▶ Play]  │
│                                 │
│  ─────────────────────────────  │
│                                 │
│  Summary                        │
│  ┌───────────────────────────┐  │
│  │ Installed new 3.5-ton     │  │
│  │ American Standard Silver  │  │
│  │ 15 system. Discovered     │  │
│  │ corroded wiring in the    │  │
│  │ existing disconnect box   │  │
│  │ and replaced it. Charged  │  │
│  │ system with 4 lbs R-410A. │  │
│  │ All functions tested and  │  │
│  │ operating normally.       │  │
│  │ Customer satisfied with   │  │
│  │ installation.             │  │
│  │                    [Edit] │  │
│  └───────────────────────────┘  │
│                                 │
│      [ Use This Summary ]       │
│                                 │
└─────────────────────────────────┘
```

### No-Show Risk Dashboard
```
┌────────────────────────────────────────────────────────────────────────┐
│  At-Risk Appointments                                  Jan 22, 2025   │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  3 appointments need attention                                         │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ ⚠️ HIGH RISK (72%)                                             │   │
│  │                                                                │   │
│  │ Bob Wilson • 10:00 AM • Service Call                          │   │
│  │ 789 Pine Road, Auburn                                          │   │
│  │                                                                │   │
│  │ Risk Factors:                                                  │   │
│  │ • Previous no-show (Jun 2024)                                 │   │
│  │ • No reply to confirmation SMS                                │   │
│  │ • Scheduled 3 weeks ago                                       │   │
│  │                                                                │   │
│  │ [📞 Call to Confirm]  [📱 Send SMS]  [Reschedule]             │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ ⚠️ MEDIUM RISK (45%)                                           │   │
│  │                                                                │   │
│  │ New Customer • 2:00 PM • AC Install                           │   │
│  │ 456 Oak Avenue, Opelika                                        │   │
│  │                                                                │   │
│  │ Risk Factors:                                                  │   │
│  │ • First-time customer                                         │   │
│  │ • Booked via AI receptionist                                  │   │
│  │                                                                │   │
│  │ [📞 Call to Confirm]  [📱 Send SMS]                           │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 5.6 Implementation Checklist

### Sprint 12 (Week 21-22): Voice Receptionist

#### Twilio Voice Setup
- [ ] Configure Twilio voice webhook
- [ ] Purchase voice-enabled phone number
- [ ] Setup TwiML bins for fallback
- [ ] Configure status callbacks

#### ElevenLabs Integration
- [ ] Create ElevenLabs account
- [ ] Select/clone voice (Clara)
- [ ] Setup conversational AI agent
- [ ] Configure voice settings (speed, stability)

#### Conversation Handler
- [ ] Create `app/services/voice_service.py`
- [ ] Build conversation state machine
- [ ] Implement intents:
  - [ ] New appointment booking
  - [ ] Status inquiry ("where's my tech?")
  - [ ] Reschedule request
  - [ ] Cancel request
  - [ ] Transfer to human
  - [ ] After-hours message
- [ ] Integrate with Claude for natural responses
- [ ] Connect to schedule availability
- [ ] Auto-create customer and job

#### Voice UI
- [ ] Create voice calls list page
- [ ] Create transcript view modal
- [ ] Add call log to customer detail
- [ ] Audio playback component
- [ ] Real-time call indicator

### Sprint 13 (Week 23-24): Voice Notes & Smart Dispatch

#### Voice Notes
- [ ] Create voice note upload endpoint
- [ ] Integrate Whisper API for transcription
- [ ] Integrate Claude for summarization
- [ ] Create processing queue (background)
- [ ] Mobile: Recording component
- [ ] Mobile: Processing status UI
- [ ] Mobile: Summary review/edit

#### Smart Dispatch
- [ ] Create dispatch suggestion algorithm
- [ ] Factor calculations:
  - [ ] Distance scoring (Mapbox)
  - [ ] Availability scoring
  - [ ] Skill matching
  - [ ] Performance history
- [ ] Create suggestion endpoint
- [ ] Update dispatch assign modal
- [ ] One-click assign integration

#### No-Show Prediction
- [ ] Create risk scoring function
- [ ] Build historical analysis query
- [ ] Create at-risk jobs endpoint
- [ ] Dashboard widget for at-risk
- [ ] Integrate with reminder system

---

## 5.7 Claude Code Prompts

### Prompt 1: Voice Receptionist
```
Build AI voice receptionist with Twilio + ElevenLabs:

Twilio Integration:
- Incoming call webhook handler
- TwiML response generation
- Call status tracking
- Recording storage

ElevenLabs:
- Conversational AI with Clara voice
- Streaming responses for low latency
- Interrupt handling

Conversation Flow:
1. Greeting with company name
2. Understand intent (book, status, reschedule, cancel, other)
3. For booking:
   - Collect name, phone, address, service type
   - Check availability via internal API
   - Offer time slots
   - Confirm appointment
   - Create customer + job records
4. For status:
   - Look up by phone number
   - Provide tech ETA or appointment details
5. For complex requests:
   - Transfer to office number
   - Take message if after hours

Use Claude API for intent classification and response generation.
Store full transcript and call outcome.
```

### Prompt 2: Voice Notes
```
Implement voice note transcription and summarization:

Upload Flow:
- Accept audio file (m4a, wav, mp3)
- Store in S3 or local storage
- Return upload ID

Processing Pipeline:
1. Send audio to Whisper API
2. Receive transcription
3. Send transcription to Claude with prompt:
   "Summarize this technician's job completion notes into a professional,
   concise paragraph suitable for customer records. Include: work performed,
   any issues found, parts used, and final status."
4. Store transcription and summary
5. WebSocket notification when complete

Mobile UI:
- Record button with waveform
- Recording timer
- Stop and submit
- Processing spinner
- Display summary with edit option
- "Use This" button to populate completion notes
```

### Prompt 3: Smart Dispatch
```
Build smart dispatch recommendation system:

Scoring Algorithm:
- Distance: 40% weight
  - < 5 miles: 100 points
  - 5-10 miles: 75 points
  - 10-20 miles: 50 points
  - > 20 miles: 25 points

- Availability: 30% weight
  - Available now: 100 points
  - Available within 2 hours: 75 points
  - Available today: 50 points

- Skill Match: 20% weight
  - Exact match (install tech for install): 100 points
  - Can do: 50 points

- Performance: 10% weight
  - Based on on-time percentage and ratings

API:
- POST /dispatch/suggest with job_id
- Return top 3 recommendations with:
  - Score breakdown
  - Reasoning strings
  - Available time slots
  - ETA calculation

UI:
- Replace manual dropdown with AI suggestions
- Show score and reasons
- One-click assign with best time
```

---

## 5.8 Files to Create

```
backend/
├── app/
│   ├── api/v1/
│   │   ├── voice.py            # NEW
│   │   └── voice_notes.py      # NEW
│   ├── models/
│   │   ├── voice_call.py       # NEW
│   │   └── voice_note.py       # NEW
│   ├── services/
│   │   ├── voice_service.py    # NEW
│   │   ├── transcription_service.py  # NEW
│   │   ├── ai_service.py       # NEW (Claude integration)
│   │   └── dispatch_service.py # UPDATE (add suggestions)
│   └── tasks/
│       └── voice_tasks.py      # NEW (background processing)

frontend/
├── src/
│   ├── components/
│   │   ├── voice/
│   │   │   ├── CallLog.tsx         # NEW
│   │   │   ├── TranscriptModal.tsx # NEW
│   │   │   └── AudioPlayer.tsx     # NEW
│   │   └── dispatch/
│   │       └── AISuggestions.tsx   # NEW
│   └── pages/
│       └── VoiceCalls.tsx          # NEW

mobile/
├── components/
│   └── VoiceRecorder.tsx       # NEW
```

---

**End of Phase 5 Documentation**

Proceed to `PHASE6_AI_WAVE2.md` after completing Phase 5.
