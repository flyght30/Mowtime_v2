# Phase 8: Integrations

**Duration:** 3 weeks
**Prerequisites:** Phase 7 complete
**Goal:** Connect to Housecall Pro, QuickBooks, and Zapier

---

## 8.1 Goals

By end of Phase 8, contractors can:
- Sync jobs bidirectionally with Housecall Pro
- Push invoices to QuickBooks
- Sync customer records
- Trigger webhooks for Zapier automations
- Use TheWorx alongside existing tools

---

## 8.2 Integrations

### Housecall Pro

**Sync Capabilities:**
- Customers: Bidirectional sync
- Jobs: Push TheWorx jobs to HCP
- Jobs: Pull HCP jobs into TheWorx
- Schedule: Sync appointments
- Status: Mirror status changes

**Use Cases:**
- Use TheWorx for estimates, HCP for invoicing
- Use HCP mobile app for field techs
- Migrate gradually from HCP to TheWorx

### QuickBooks Online

**Sync Capabilities:**
- Customers: Push to QBO
- Invoices: Create from completed jobs
- Payments: Record when paid
- Items: Sync service items

**Use Cases:**
- Accounting in QuickBooks
- Financial reporting
- Tax preparation

### Zapier / Webhooks

**Outbound Events:**
- job.created
- job.status_changed
- job.completed
- customer.created
- appointment.scheduled
- invoice.created
- payment.received

**Inbound Triggers:**
- Webhook endpoint for custom integrations
- Create jobs from form submissions
- Create customers from CRM

---

## 8.3 Database Models

### Integration
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "provider": "housecall_pro" | "quickbooks" | "zapier" | "webhook",
  
  "is_active": bool,
  "connected_at": datetime,
  
  "credentials": {
    "access_token": str,          # Encrypted
    "refresh_token": str,         # Encrypted
    "expires_at": datetime,
    "account_id": str | None
  },
  
  "settings": {
    # Provider-specific settings
  },
  
  "sync_status": {
    "last_sync": datetime | None,
    "last_error": str | None,
    "items_synced": int
  },
  
  "created_at": datetime,
  "updated_at": datetime
}
```

### SyncMapping
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "integration_id": ObjectId,
  
  "local_type": "customer" | "job" | "invoice",
  "local_id": ObjectId,
  "remote_id": str,
  
  "last_synced": datetime,
  "sync_direction": "push" | "pull" | "bidirectional",
  
  "created_at": datetime
}
```

### WebhookSubscription
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  
  "url": str,
  "events": [str],                # ["job.created", "job.completed"]
  "secret": str,                  # For signature verification
  
  "is_active": bool,
  "last_triggered": datetime | None,
  "failure_count": int,
  
  "created_at": datetime
}
```

### WebhookLog
```python
{
  "_id": ObjectId,
  "subscription_id": ObjectId,
  
  "event": str,
  "payload": dict,
  "response_status": int | None,
  "response_body": str | None,
  "error": str | None,
  
  "created_at": datetime
}
```

---

## 8.4 API Endpoints

### Integrations

```
GET /api/v1/integrations
Response: {
  "items": [
    {
      "provider": "housecall_pro",
      "is_active": true,
      "connected_at": "2025-01-15T10:00:00Z",
      "sync_status": { ... }
    }
  ]
}

GET /api/v1/integrations/{provider}
Response: Full integration details

POST /api/v1/integrations/{provider}/connect
# Initiate OAuth flow
Response: { "auth_url": "https://..." }

GET /api/v1/integrations/{provider}/callback
# OAuth callback handler
Query: ?code=...&state=...
Response: Redirect to settings

DELETE /api/v1/integrations/{provider}
# Disconnect integration
Response: { "disconnected": true }

POST /api/v1/integrations/{provider}/sync
# Trigger manual sync
Response: { "sync_started": true, "job_id": "..." }

GET /api/v1/integrations/{provider}/sync-status
Response: {
  "in_progress": false,
  "last_sync": "...",
  "items_synced": 45,
  "errors": []
}
```

### Housecall Pro Specific

```
POST /api/v1/integrations/housecall-pro/push-job
Request: { "job_id": "..." }
Response: { "hcp_job_id": "...", "url": "..." }

POST /api/v1/integrations/housecall-pro/pull-jobs
Request: { "since": "2025-01-01" }
Response: { "jobs_imported": 15 }

GET /api/v1/integrations/housecall-pro/match-customers
Response: {
  "unmatched_local": 5,
  "unmatched_remote": 12,
  "matched": 150
}
```

### QuickBooks Specific

```
POST /api/v1/integrations/quickbooks/create-invoice
Request: { "job_id": "..." }
Response: { "qb_invoice_id": "...", "invoice_number": "1042" }

POST /api/v1/integrations/quickbooks/sync-customers
Response: { "synced": 45, "errors": [] }

GET /api/v1/integrations/quickbooks/accounts
Response: List of QBO income/expense accounts for mapping
```

### Webhooks

```
GET /api/v1/webhooks
Response: List of webhook subscriptions

POST /api/v1/webhooks
Request: {
  "url": "https://hooks.zapier.com/...",
  "events": ["job.completed", "customer.created"]
}
Response: Created subscription with secret

PUT /api/v1/webhooks/{id}
Request: { "events": [...], "is_active": true }
Response: Updated subscription

DELETE /api/v1/webhooks/{id}
Response: { "deleted": true }

GET /api/v1/webhooks/{id}/logs
Response: Recent webhook deliveries with status

POST /api/v1/webhooks/{id}/test
Response: { "delivered": true, "response": "..." }
```

---

## 8.5 Wireframes

### Integrations Page
```
┌────────────────────────────────────────────────────────────────────────┐
│  Settings > Integrations                                               │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  Connected                                                             │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ ┌────┐                                                         │   │
│  │ │ HCP│  Housecall Pro                          ● Connected    │   │
│  │ └────┘                                                         │   │
│  │       Last sync: 2 hours ago • 156 customers, 89 jobs synced  │   │
│  │                                                                │   │
│  │       [Sync Now]  [Settings]  [Disconnect]                    │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ ┌────┐                                                         │   │
│  │ │ QB │  QuickBooks Online                      ● Connected    │   │
│  │ └────┘                                                         │   │
│  │       Account: ABC Heating & Air LLC                          │   │
│  │       45 invoices synced                                       │   │
│  │                                                                │   │
│  │       [Sync Now]  [Settings]  [Disconnect]                    │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  Available                                                             │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ ┌────┐                                                         │   │
│  │ │ GC │  Google Calendar                        [Connect]      │   │
│  │ └────┘  Sync tech schedules                                    │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  Webhooks                                                              │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │                                                                │   │
│  │  2 active webhooks                            [+ Add Webhook] │   │
│  │                                                                │   │
│  │  Zapier - Job Notifications                   ● Active        │   │
│  │  Events: job.created, job.completed                           │   │
│  │                                                                │   │
│  │  Custom CRM                                   ● Active        │   │
│  │  Events: customer.created                                      │   │
│  │                                                                │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### HCP Integration Settings
```
┌─────────────────────────────────────────────────────────────────┐
│  Housecall Pro Settings                                  [✕]    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Sync Settings                                                  │
│                                                                 │
│  Customers                                                      │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ ☑ Sync customers bidirectionally                        │   │
│  │ ☐ Only push new customers to HCP                        │   │
│  │ ☐ Only pull customers from HCP                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Jobs                                                           │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ ☑ Push jobs to HCP when scheduled                       │   │
│  │ ☑ Sync status changes                                   │   │
│  │ ☐ Pull jobs from HCP (for migration)                    │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Field Mapping                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ TheWorx Job Type  →  HCP Job Type                       │   │
│  │ ─────────────────────────────────────────────────────── │   │
│  │ Install          →  [Installation          ▼]           │   │
│  │ Service          →  [Service Call          ▼]           │   │
│  │ Maintenance      →  [Maintenance           ▼]           │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Auto-Sync                                                      │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ ☑ Enable automatic sync                                 │   │
│  │   Sync every: [1 hour               ▼]                  │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│                                       [Cancel] [Save Settings]  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Webhook Setup
```
┌─────────────────────────────────────────────────────────────────┐
│  Add Webhook                                             [✕]    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Endpoint URL                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ https://hooks.zapier.com/hooks/catch/123456/abcdef     │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Events to Send                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ ☑ job.created         ☑ job.completed                  │   │
│  │ ☑ job.status_changed  ☐ job.cancelled                  │   │
│  │ ☑ customer.created    ☐ customer.updated               │   │
│  │ ☐ appointment.scheduled                                 │   │
│  │ ☐ invoice.created     ☐ payment.received               │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Security                                                       │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Signing Secret (auto-generated):                        │   │
│  │ whsec_abc123def456...                         [Copy]    │   │
│  │                                                         │   │
│  │ Use this to verify webhook signatures                   │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  [Test Webhook]                                                 │
│                                                                 │
│                                       [Cancel] [Create Webhook] │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 8.6 Implementation Checklist

### Sprint 19 (Week 35-36): HCP + QuickBooks

#### Housecall Pro Integration
- [ ] Register HCP API application
- [ ] Implement OAuth 2.0 flow
- [ ] Token refresh handling
- [ ] Customer sync (bidirectional)
- [ ] Job push to HCP
- [ ] Status change webhooks
- [ ] Field mapping configuration
- [ ] Sync status tracking

#### QuickBooks Integration
- [ ] Register QBO application
- [ ] Implement OAuth 2.0 flow
- [ ] Customer sync
- [ ] Invoice creation
- [ ] Payment recording
- [ ] Account mapping UI

### Sprint 20 (Week 37): Webhooks + Polish

#### Webhook System
- [ ] Webhook subscription CRUD
- [ ] Event dispatcher
- [ ] Payload signing (HMAC)
- [ ] Delivery with retry
- [ ] Delivery logging
- [ ] Test webhook endpoint
- [ ] Webhook management UI

#### Integration Polish
- [ ] Connection status indicators
- [ ] Sync progress display
- [ ] Error handling and display
- [ ] Manual sync triggers
- [ ] Disconnect confirmation

---

## 8.7 Files to Create

```
backend/
├── app/
│   ├── api/v1/
│   │   ├── integrations.py     # NEW
│   │   └── webhooks.py         # NEW
│   ├── models/
│   │   ├── integration.py      # NEW
│   │   └── webhook.py          # NEW
│   ├── services/
│   │   ├── integrations/
│   │   │   ├── __init__.py     # NEW
│   │   │   ├── base.py         # NEW
│   │   │   ├── housecall.py    # NEW
│   │   │   └── quickbooks.py   # NEW
│   │   └── webhook_service.py  # NEW
│   └── tasks/
│       └── sync_tasks.py       # NEW

frontend/
├── src/
│   ├── components/
│   │   └── integrations/
│   │       ├── IntegrationCard.tsx     # NEW
│   │       ├── HCPSettings.tsx         # NEW
│   │       ├── QBSettings.tsx          # NEW
│   │       └── WebhookForm.tsx         # NEW
│   └── pages/
│       └── Settings/
│           └── Integrations.tsx        # NEW
```

---

**End of Phase 8 Documentation**

Proceed to `PHASE9_ANALYTICS.md` after completing Phase 8.
