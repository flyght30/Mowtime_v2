# Phase 2: Dispatch & Scheduling

**Duration:** 5 weeks
**Prerequisites:** Phase 1 complete
**Goal:** Full dispatch board with GPS tracking and scheduling

---

## 2.1 Goals

By end of Phase 2, contractors can:
- Add and manage technicians
- View dispatch board with map and job queue
- Assign jobs to technicians
- Track technician location in real-time
- See technician status (available, enroute, on site, complete)
- View optimized routes for multi-job days

---

## 2.2 Database Models

### Technician
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "user_id": ObjectId | None,        # Link to user account if they have app access
  "first_name": str,
  "last_name": str,
  "phone": str,
  "email": str | None,
  
  "status": "available" | "assigned" | "enroute" | "on_site" | "complete" | "off_duty",
  "current_job_id": ObjectId | None,
  "next_job_id": ObjectId | None,
  
  "location": {
    "type": "Point",
    "coordinates": [lng, lat],
    "timestamp": datetime,
    "accuracy": float | None
  },
  
  "certifications": [str],           # ["EPA_608", "NATE", "OSHA_10"]
  "skills": {
    "can_install": bool,
    "can_service": bool,
    "can_maintenance": bool
  },
  
  "schedule": {
    "work_days": [int],              # [1,2,3,4,5] = Mon-Fri
    "start_time": str,               # "08:00"
    "end_time": str,                 # "17:00"
    "lunch_start": str,              # "12:00"
    "lunch_duration": int            # 60 minutes
  },
  
  "stats": {
    "jobs_completed": int,
    "avg_rating": float | None,
    "on_time_percentage": float
  },
  
  "is_active": bool,
  "created_at": datetime,
  "updated_at": datetime
}
```

### TechLocation (for historical tracking)
```python
{
  "_id": ObjectId,
  "tech_id": ObjectId,
  "company_id": ObjectId,
  "location": {
    "type": "Point",
    "coordinates": [lng, lat]
  },
  "accuracy": float | None,
  "timestamp": datetime
}
# TTL index: expires after 7 days
```

### ScheduleEntry
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "tech_id": ObjectId,
  "job_id": ObjectId,
  "date": date,
  "start_time": str,                 # "09:00"
  "end_time": str,                   # "15:00"
  "estimated_hours": float,
  "status": "scheduled" | "in_progress" | "complete" | "cancelled",
  "order": int,                      # Position in day's route
  "travel_time_minutes": int | None,
  "created_at": datetime,
  "updated_at": datetime
}
```

### Update Job Model (additions)
```python
{
  # ... existing fields ...
  
  "schedule": {
    "scheduled_date": date | None,
    "scheduled_time_start": str | None,
    "scheduled_time_end": str | None,
    "tech_id": ObjectId | None,
    "estimated_hours": float,
    "schedule_entry_id": ObjectId | None
  },
  
  "tracking": {
    "assigned_at": datetime | None,
    "enroute_at": datetime | None,
    "arrived_at": datetime | None,
    "started_at": datetime | None,
    "completed_at": datetime | None,
    "travel_time_minutes": int | None,
    "job_duration_minutes": int | None
  }
}
```

---

## 2.3 API Endpoints

### Technicians

```
GET /api/v1/technicians
Query: ?status=available&include_location=true
Response:
{
  "items": [
    {
      "id": "...",
      "first_name": "Mike",
      "last_name": "Johnson",
      "phone": "555-111-2222",
      "status": "available",
      "current_job": null,
      "next_job": { "id": "...", "customer_name": "John Smith", "address": "..." },
      "location": {
        "lat": 32.6099,
        "lng": -85.4808,
        "timestamp": "2025-01-22T10:30:00Z"
      },
      "skills": { "can_install": true, "can_service": true }
    }
  ],
  "total": 6
}

GET /api/v1/technicians/{id}
Response: Full technician object with stats

POST /api/v1/technicians
Request:
{
  "first_name": "Mike",
  "last_name": "Johnson",
  "phone": "555-111-2222",
  "email": "mike@abchvac.com",
  "certifications": ["EPA_608", "NATE"],
  "skills": { "can_install": true, "can_service": true },
  "schedule": {
    "work_days": [1, 2, 3, 4, 5],
    "start_time": "08:00",
    "end_time": "17:00"
  }
}
Response: Created technician

PUT /api/v1/technicians/{id}
Request: Partial update
Response: Updated technician

DELETE /api/v1/technicians/{id}
Response: { "deleted": true }

PATCH /api/v1/technicians/{id}/status
Request:
{
  "status": "enroute",
  "job_id": "..."
}
Response: Updated technician

POST /api/v1/technicians/{id}/location
Request:
{
  "lat": 32.6099,
  "lng": -85.4808,
  "accuracy": 10.5,
  "timestamp": "2025-01-22T10:30:00Z"
}
Response: { "received": true }
```

### Schedule

```
GET /api/v1/schedule
Query: ?date=2025-01-22&tech_id=...
Response:
{
  "date": "2025-01-22",
  "technicians": [
    {
      "tech_id": "...",
      "tech_name": "Mike Johnson",
      "entries": [
        {
          "id": "...",
          "job_id": "...",
          "customer_name": "John Smith",
          "address": "123 Main St",
          "start_time": "09:00",
          "end_time": "15:00",
          "status": "scheduled",
          "order": 1
        }
      ],
      "available_slots": [
        { "start": "08:00", "end": "09:00" },
        { "start": "15:00", "end": "17:00" }
      ]
    }
  ]
}

GET /api/v1/schedule/week
Query: ?start_date=2025-01-20&tech_id=...
Response: Array of daily schedules

POST /api/v1/schedule/assign
Request:
{
  "job_id": "...",
  "tech_id": "...",
  "date": "2025-01-22",
  "start_time": "09:00",
  "estimated_hours": 6
}
Response:
{
  "schedule_entry": { ... },
  "job": { ... updated job ... },
  "conflicts": []
}

PUT /api/v1/schedule/{entry_id}
Request:
{
  "start_time": "10:00",
  "estimated_hours": 5
}
Response: Updated entry

DELETE /api/v1/schedule/{entry_id}
Response: { "deleted": true, "job_status": "approved" }

POST /api/v1/schedule/optimize
Request:
{
  "tech_id": "...",
  "date": "2025-01-22"
}
Response:
{
  "original_order": [...],
  "optimized_order": [...],
  "time_saved_minutes": 45,
  "total_drive_time_minutes": 62
}
```

### Dispatch

```
GET /api/v1/dispatch/queue
Query: ?status=approved&status=scheduled
Response:
{
  "unassigned": [
    {
      "id": "...",
      "job_number": "JOB-2025-0045",
      "customer_name": "John Smith",
      "address": "123 Main St, Auburn, AL",
      "location": { "lat": 32.6099, "lng": -85.4808 },
      "job_type": "install",
      "estimated_hours": 6,
      "priority": "normal",
      "created_at": "2025-01-21T10:00:00Z"
    }
  ],
  "assigned_today": [...],
  "total_unassigned": 5
}

GET /api/v1/dispatch/map-data
Query: ?date=2025-01-22
Response:
{
  "technicians": [
    {
      "id": "...",
      "name": "Mike Johnson",
      "status": "enroute",
      "location": { "lat": 32.6099, "lng": -85.4808 },
      "current_job": { "id": "...", "address": "..." }
    }
  ],
  "jobs": [
    {
      "id": "...",
      "location": { "lat": 32.6150, "lng": -85.4900 },
      "status": "scheduled",
      "tech_id": "...",
      "scheduled_time": "09:00"
    }
  ]
}

POST /api/v1/dispatch/suggest-tech
Request:
{
  "job_id": "..."
}
Response:
{
  "suggestions": [
    {
      "tech_id": "...",
      "tech_name": "Mike Johnson",
      "score": 92,
      "reasons": [
        "Closest to job site (8 min)",
        "Has availability at 2:00 PM",
        "Install certified"
      ],
      "eta_minutes": 8,
      "available_slot": { "start": "14:00", "end": "17:00" }
    }
  ]
}

GET /api/v1/dispatch/route
Query: ?tech_id=...&date=2025-01-22
Response:
{
  "tech_id": "...",
  "date": "2025-01-22",
  "stops": [
    {
      "order": 1,
      "job_id": "...",
      "address": "123 Main St",
      "location": { "lat": 32.6099, "lng": -85.4808 },
      "arrival_time": "09:00",
      "departure_time": "15:00",
      "travel_from_previous": 0
    },
    {
      "order": 2,
      "job_id": "...",
      "address": "456 Oak Ave",
      "location": { "lat": 32.6200, "lng": -85.5000 },
      "arrival_time": "15:15",
      "departure_time": "16:30",
      "travel_from_previous": 15
    }
  ],
  "total_drive_time": 35,
  "route_geometry": "..." // Mapbox encoded polyline
}
```

### WebSocket (Real-time updates)

```
WS /api/v1/ws/dispatch

# Server → Client messages:
{
  "type": "tech_location",
  "tech_id": "...",
  "location": { "lat": 32.6099, "lng": -85.4808 },
  "timestamp": "2025-01-22T10:30:00Z"
}

{
  "type": "tech_status",
  "tech_id": "...",
  "status": "on_site",
  "job_id": "..."
}

{
  "type": "job_update",
  "job_id": "...",
  "status": "in_progress"
}

# Client → Server messages:
{
  "type": "subscribe",
  "channels": ["dispatch", "tech_locations"]
}
```

---

## 2.4 Wireframes

### Dispatch Board - Main View
```
┌────────────────────────────────────────────────────────────────────────┐
│  Dispatch                     [Today ▼] Jan 22, 2025    [Day][Week]   │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ┌──────────────────────────┐  ┌─────────────────────────────────────┐│
│  │ Unassigned Jobs (5)      │  │                                     ││
│  │ ─────────────────────────│  │           [MAP VIEW]                ││
│  │                          │  │                                     ││
│  │ ┌──────────────────────┐ │  │    📍 Mike - Enroute               ││
│  │ │ JOB-2025-0045        │ │  │              ↘                     ││
│  │ │ John Smith           │ │  │         📍 Job Site                ││
│  │ │ 123 Main St          │ │  │                                     ││
│  │ │ Install 3.5T • 6 hrs │ │  │                   📍 Sarah          ││
│  │ │ [Assign ▼]           │ │  │                     (On Site)       ││
│  │ └──────────────────────┘ │  │                                     ││
│  │                          │  │      📍 Tom                         ││
│  │ ┌──────────────────────┐ │  │       (Available)                   ││
│  │ │ JOB-2025-0046        │ │  │                                     ││
│  │ │ Mary Jones           │ │  │                                     ││
│  │ │ 456 Oak Ave          │ │  │    ○ = Job    📍 = Tech            ││
│  │ │ Service • 2 hrs      │ │  │                                     ││
│  │ │ [Assign ▼]           │ │  └─────────────────────────────────────┘│
│  │ └──────────────────────┘ │                                         │
│  │                          │  Technicians (4)                        │
│  │ ┌──────────────────────┐ │  ┌─────────────────────────────────────┐│
│  │ │ JOB-2025-0047        │ │  │                                     ││
│  │ │ Bob Wilson           │ │  │ ┌─────────┐ ┌─────────┐ ┌─────────┐││
│  │ │ 789 Pine Rd          │ │  │ │●ENROUTE │ │● ON SITE│ │○AVAILABL│││
│  │ │ Install 4T • 7 hrs   │ │  │ │ Mike J. │ │ Sarah K.│ │ Tom B.  │││
│  │ │ [Assign ▼]           │ │  │ │         │ │         │ │         │││
│  │ └──────────────────────┘ │  │ │ Current:│ │ Current:│ │ Next:   │││
│  │                          │  │ │ J Smith │ │ M Jones │ │ None    │││
│  │ + 2 more                 │  │ │ ETA: 8m │ │ Since:  │ │         │││
│  │                          │  │ │         │ │ 10:30AM │ │ [Assign]│││
│  └──────────────────────────┘  │ └─────────┘ └─────────┘ └─────────┘││
│                                │                                     ││
│                                │ ┌─────────┐                         ││
│                                │ │○OFF DUTY│                         ││
│                                │ │ Dave R. │                         ││
│                                │ │ (PTO)   │                         ││
│                                │ └─────────┘                         ││
│                                └─────────────────────────────────────┘│
└────────────────────────────────────────────────────────────────────────┘
```

### Dispatch Board - Week View
```
┌────────────────────────────────────────────────────────────────────────┐
│  Dispatch                     [Week ▼] Jan 20-24        [Day][Week]   │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│          │  Mon 20  │  Tue 21  │  Wed 22  │  Thu 23  │  Fri 24  │     │
│  ────────┼──────────┼──────────┼──────────┼──────────┼──────────┤     │
│          │          │          │          │          │          │     │
│  Mike J. │ ████████ │ ████     │ ████████ │          │ ████████ │     │
│          │ J.Smith  │ Service  │ T.Brown  │          │ L.Chen   │     │
│          │ Install  │          │ Install  │          │ Install  │     │
│  ────────┼──────────┼──────────┼──────────┼──────────┼──────────┤     │
│          │          │          │          │          │          │     │
│  Sarah K.│ ████     │ ████████ │          │ ████████ │ ████     │     │
│          │ Service  │ M.Jones  │          │ R.Garcia │ Maint.   │     │
│          │          │ Install  │          │ Install  │          │     │
│  ────────┼──────────┼──────────┼──────────┼──────────┼──────────┤     │
│          │          │          │          │          │          │     │
│  Tom B.  │          │ ████     │ ████     │ ████     │          │     │
│          │          │ Maint.   │ Service  │ Service  │          │     │
│          │          │          │          │          │          │     │
│  ────────┼──────────┼──────────┼──────────┼──────────┼──────────┤     │
│                                                                        │
│  Unassigned: 3 jobs                               [+ Add Time Off]    │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Tech Card Expanded
```
┌─────────────────────────────────────────┐
│  ● ENROUTE                              │
│  ─────────────────────────────────────  │
│  Mike Johnson                           │
│  📱 (555) 111-2222                      │
│                                         │
│  Current Job                            │
│  ┌─────────────────────────────────┐   │
│  │ John Smith                       │   │
│  │ 123 Main Street, Auburn          │   │
│  │ Install 3.5T Am Std              │   │
│  │ ETA: 8 minutes                   │   │
│  │                                  │   │
│  │ [📍 Track] [📞 Call] [💬 Text]   │   │
│  └─────────────────────────────────┘   │
│                                         │
│  Next Job                               │
│  ┌─────────────────────────────────┐   │
│  │ Mary Jones                       │   │
│  │ 456 Oak Ave, Opelika             │   │
│  │ Scheduled: 3:00 PM               │   │
│  └─────────────────────────────────┘   │
│                                         │
│  Today's Stats                          │
│  Jobs: 1/2  │  Drive: 35 min           │
│                                         │
│  [View Full Schedule]                   │
└─────────────────────────────────────────┘
```

### Assign Job Modal
```
┌─────────────────────────────────────────────────────────────────┐
│  Assign Job                                              [✕]    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  JOB-2025-0045 • John Smith • 123 Main St                      │
│  Install 3.5T American Standard • Est. 6 hours                 │
│                                                                 │
│  ───────────────────────────────────────────────────────────── │
│                                                                 │
│  Recommended                                                    │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ ⭐ Mike Johnson                              Score: 92   │   │
│  │    • 8 min from job site                                │   │
│  │    • Available 2:00 PM - 5:00 PM                        │   │
│  │    • Install certified                                  │   │
│  │                                         [Select]        │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Other Available                                                │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Tom Baker                                    Score: 78   │   │
│  │    • 22 min from job site                               │   │
│  │    • Available all day                                  │   │
│  │                                         [Select]        │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Sarah Kim                                    Score: 65   │   │
│  │    • 15 min from job site                               │   │
│  │    • Available after 4:00 PM (current job)              │   │
│  │                                         [Select]        │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ───────────────────────────────────────────────────────────── │
│                                                                 │
│  Schedule For                                                   │
│  Date: [Jan 22, 2025    ▼]   Time: [2:00 PM ▼]                 │
│                                                                 │
│                                            [Cancel] [Assign]    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Technician List Page
```
┌────────────────────────────────────────────────────────────────────────┐
│  Technicians                                          [+ Add Tech]    │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  [All] [Active] [Off Duty]                              🔍 Search     │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ Mike Johnson                                       ● Available │   │
│  │ 📱 (555) 111-2222 • mike@abchvac.com                          │   │
│  │                                                                │   │
│  │ Certifications: EPA 608, NATE                                 │   │
│  │ Skills: Install ✓  Service ✓  Maintenance ✓                   │   │
│  │                                                                │   │
│  │ Schedule: Mon-Fri 8:00 AM - 5:00 PM                           │   │
│  │ This Week: 4 jobs • 28 hours                                  │   │
│  │                                                                │   │
│  │ [View Schedule]  [Edit]                                       │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ Sarah Kim                                          ● On Site   │   │
│  │ 📱 (555) 222-3333 • sarah@abchvac.com                         │   │
│  │                                                                │   │
│  │ Certifications: EPA 608                                       │   │
│  │ Skills: Install ✓  Service ✓  Maintenance ✗                   │   │
│  │                                                                │   │
│  │ Schedule: Mon-Fri 8:00 AM - 5:00 PM                           │   │
│  │ This Week: 3 jobs • 22 hours                                  │   │
│  │                                                                │   │
│  │ [View Schedule]  [Edit]                                       │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Add/Edit Technician Form
```
┌─────────────────────────────────────────────────────────────────┐
│  Add Technician                                          [✕]    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Basic Information                                              │
│  ┌─────────────────────┐  ┌─────────────────────┐              │
│  │ First Name          │  │ Last Name           │              │
│  │ [Mike            ]  │  │ [Johnson         ]  │              │
│  └─────────────────────┘  └─────────────────────┘              │
│                                                                 │
│  ┌─────────────────────┐  ┌─────────────────────┐              │
│  │ Phone               │  │ Email               │              │
│  │ [(555) 111-2222 ]   │  │ [mike@abchvac.com]  │              │
│  └─────────────────────┘  └─────────────────────┘              │
│                                                                 │
│  Certifications                                                 │
│  ☑ EPA 608    ☑ NATE    ☐ OSHA 10    ☐ OSHA 30                │
│                                                                 │
│  Skills                                                         │
│  ☑ Can do installs                                             │
│  ☑ Can do service calls                                        │
│  ☑ Can do maintenance                                          │
│                                                                 │
│  Work Schedule                                                  │
│  Days: ☑ Mon ☑ Tue ☑ Wed ☑ Thu ☑ Fri ☐ Sat ☐ Sun             │
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │ Start Time   │  │ End Time     │  │ Lunch        │         │
│  │ [8:00 AM  ▼] │  │ [5:00 PM  ▼] │  │ [12:00 PM ▼] │         │
│  └──────────────┘  └──────────────┘  └──────────────┘         │
│                                                                 │
│  ☐ Create user account for mobile app access                   │
│                                                                 │
│                                       [Cancel] [Save Technician]│
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Route View
```
┌────────────────────────────────────────────────────────────────────────┐
│  Route - Mike Johnson                     Jan 22, 2025    [Optimize]  │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ┌────────────────────────────────┐  ┌───────────────────────────────┐│
│  │                                │  │                               ││
│  │         [MAP WITH ROUTE]       │  │  Stop 1 • 9:00 AM            ││
│  │                                │  │  ─────────────────────────── ││
│  │     🏠 Start                   │  │  John Smith                   ││
│  │       ↓ (15 min)               │  │  123 Main St, Auburn          ││
│  │     ① Job 1                    │  │  Install 3.5T                 ││
│  │       ↓ (12 min)               │  │  Est: 6 hours                 ││
│  │     ② Job 2                    │  │  Depart: ~3:00 PM             ││
│  │       ↓ (18 min)               │  │                               ││
│  │     🏠 End                     │  │  ─────────────────────────── ││
│  │                                │  │                               ││
│  │                                │  │  Stop 2 • 3:15 PM            ││
│  │                                │  │  ─────────────────────────── ││
│  │                                │  │  Mary Jones                   ││
│  │                                │  │  456 Oak Ave, Opelika         ││
│  │                                │  │  Service Call                 ││
│  │                                │  │  Est: 1.5 hours               ││
│  └────────────────────────────────┘  │  Depart: ~4:45 PM             ││
│                                      │                               ││
│  Summary                             └───────────────────────────────┘│
│  ┌─────────────────────────────────────────────────────────────────┐ │
│  │ Total Drive: 45 min  │  Jobs: 2  │  Hours: 7.5  │  End: ~5:00 PM │ │
│  └─────────────────────────────────────────────────────────────────┘ │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 2.5 Implementation Checklist

### Sprint 4 (Week 7-8): Technician Management

#### Technician Backend
- [ ] Create `app/models/technician.py`
- [ ] Create `app/api/v1/technicians.py`:
  - [ ] GET `/technicians`
  - [ ] GET `/technicians/{id}`
  - [ ] POST `/technicians`
  - [ ] PUT `/technicians/{id}`
  - [ ] DELETE `/technicians/{id}`
  - [ ] PATCH `/technicians/{id}/status`
  - [ ] POST `/technicians/{id}/location`
- [ ] Add geospatial index on location
- [ ] Write tests

#### Technician Frontend
- [ ] Create `src/components/technicians/TechCard.tsx`
- [ ] Create `src/components/technicians/TechForm.tsx`
- [ ] Create `src/pages/Technicians.tsx`
- [ ] Connect to API
- [ ] Add to navigation

#### User Account Link
- [ ] Add tech role to auth
- [ ] Link technician to user account
- [ ] Tech-specific permissions

### Sprint 5 (Week 9-10): Dispatch Board

#### Map Integration
- [ ] Install Mapbox GL JS
- [ ] Create `src/components/dispatch/MapView.tsx`
- [ ] Add tech location markers
- [ ] Add job location pins
- [ ] Add marker clustering
- [ ] Add click interactions
- [ ] Add route polylines

#### Dispatch Board Layout
- [ ] Create `src/pages/Dispatch.tsx`
- [ ] Create `src/components/dispatch/DispatchBoard.tsx`
- [ ] Create `src/components/dispatch/JobQueue.tsx`
- [ ] Create `src/components/dispatch/TechCard.tsx` (dispatch version)
- [ ] Drag-and-drop job assignment
- [ ] Day/week toggle

#### Dispatch API
- [ ] Create `app/api/v1/dispatch.py`:
  - [ ] GET `/dispatch/queue`
  - [ ] GET `/dispatch/map-data`
  - [ ] POST `/dispatch/suggest-tech`
- [ ] Create tech suggestion algorithm
- [ ] Write tests

#### Assign Job Modal
- [ ] Create `src/components/dispatch/AssignModal.tsx`
- [ ] Show recommended techs
- [ ] Date/time picker
- [ ] Conflict detection

### Sprint 6 (Week 11-12): GPS & Scheduling

#### GPS Tracking
- [ ] Create location ping endpoint
- [ ] Create TechLocation model for history
- [ ] Add TTL index (7 day expiry)
- [ ] Create `app/services/routing_service.py` (Mapbox)

#### WebSocket
- [ ] Setup FastAPI WebSocket endpoint
- [ ] Create connection manager
- [ ] Broadcast location updates
- [ ] Broadcast status changes
- [ ] Create `src/hooks/useWebSocket.ts`
- [ ] Real-time map updates

#### Schedule API
- [ ] Create ScheduleEntry model
- [ ] Create `app/api/v1/schedule.py`:
  - [ ] GET `/schedule`
  - [ ] GET `/schedule/week`
  - [ ] POST `/schedule/assign`
  - [ ] PUT `/schedule/{id}`
  - [ ] DELETE `/schedule/{id}`
- [ ] Update job status on assign
- [ ] Conflict detection

#### Calendar View
- [ ] Create `src/components/dispatch/CalendarView.tsx`
- [ ] Week view grid
- [ ] Job blocks with drag resize
- [ ] Tech rows

#### Route Optimization
- [ ] Create `app/services/routing_service.py`
- [ ] Mapbox Optimization API integration
- [ ] POST `/schedule/optimize` endpoint
- [ ] Create route view component
- [ ] Show optimized vs current comparison

---

## 2.6 Claude Code Prompts

### Prompt 1: Technician Management
```
Add technician management to TheWorx:

Backend:
- Technician model with status, location, skills, schedule, stats
- CRUD endpoints for technicians
- Status update endpoint (available, enroute, on_site, complete, off_duty)
- Location update endpoint with geospatial storage
- Link technician to user account for app access

Frontend:
- Technician list page with status indicators
- Tech card component showing status, current job, next job
- Add/Edit technician form
- Skills and certification checkboxes
- Work schedule configuration
```

### Prompt 2: Dispatch Board
```
Build the dispatch board for TheWorx:

Features:
- Split layout: Job queue (left), Map (center), Tech cards (right)
- Job queue shows unassigned jobs sorted by date
- Map shows:
  - Tech locations as markers with status colors
  - Job locations as pins
  - Route lines for enroute techs
- Tech cards show status, current job, next job
- Click job → show details popup
- Click tech → show expanded card

Use Mapbox GL JS for mapping.
Support day view and week view toggle.
```

### Prompt 3: GPS Tracking
```
Implement real-time GPS tracking:

Backend:
- POST /technicians/{id}/location endpoint
- Store location history with TTL (7 days)
- WebSocket endpoint for broadcasting updates
- Geofence detection for auto-arrival

Frontend:
- useWebSocket hook for real-time updates
- Update tech markers on location change
- Update status badges on status change
- Show ETA based on current location
- Smooth marker animation on position update
```

### Prompt 4: Scheduling System
```
Build the scheduling system:

Backend:
- ScheduleEntry model linking job, tech, date, time
- Schedule CRUD endpoints
- Conflict detection (overlapping times)
- Available slot calculation
- Automatic job status update on assign/unassign

Frontend:
- Assign job modal with:
  - Recommended techs (scored by distance, skills, availability)
  - Date picker
  - Time slot picker
  - Conflict warnings
- Calendar week view:
  - Tech rows
  - Job blocks
  - Drag to reschedule
  - Resize to change duration
```

### Prompt 5: Route Optimization
```
Add route optimization:

Backend:
- Mapbox Optimization API integration
- POST /schedule/optimize endpoint
- Calculate optimal job order
- Return time savings and route geometry

Frontend:
- Route view showing map with numbered stops
- Stop list with times and durations
- "Optimize" button
- Before/after comparison
- One-click apply optimized order
```

---

## 2.7 Files to Create

```
backend/
├── app/
│   ├── api/v1/
│   │   ├── technicians.py      # NEW
│   │   ├── schedule.py         # NEW
│   │   ├── dispatch.py         # NEW
│   │   └── websocket.py        # NEW
│   ├── models/
│   │   ├── technician.py       # NEW
│   │   └── schedule.py         # NEW
│   └── services/
│       ├── routing_service.py  # NEW
│       └── dispatch_service.py # NEW

frontend/
├── src/
│   ├── components/
│   │   ├── technicians/
│   │   │   ├── TechCard.tsx    # NEW
│   │   │   ├── TechForm.tsx    # NEW
│   │   │   └── TechList.tsx    # NEW
│   │   └── dispatch/
│   │       ├── DispatchBoard.tsx   # NEW
│   │       ├── JobQueue.tsx        # NEW
│   │       ├── TechPanel.tsx       # NEW
│   │       ├── MapView.tsx         # NEW
│   │       ├── CalendarView.tsx    # NEW
│   │       ├── AssignModal.tsx     # NEW
│   │       └── RouteView.tsx       # NEW
│   ├── pages/
│   │   ├── Technicians.tsx     # NEW
│   │   └── Dispatch.tsx        # NEW
│   └── hooks/
│       ├── useWebSocket.ts     # NEW
│       ├── useTechnicians.ts   # NEW
│       └── useSchedule.ts      # NEW
```

---

## 2.8 Test Scenarios

### Technician Management
1. Add new technician → appears in list
2. Update tech status → status badge updates
3. Tech location update → marker moves on map
4. Delete tech with assigned jobs → shows warning

### Dispatch Board
1. Load board → shows unassigned jobs and techs
2. Map shows all tech locations and job pins
3. Click tech marker → shows info popup
4. Drag job to tech → opens assign modal

### GPS Tracking
1. Location update → marker moves smoothly
2. Enter geofence → auto-detect arrival
3. WebSocket disconnect → reconnect automatically
4. Multiple dispatchers see same updates

### Scheduling
1. Assign job → job moves from queue to scheduled
2. Assign to busy slot → shows conflict warning
3. Change date → updates calendar
4. Unassign job → returns to queue

### Route Optimization
1. View route → shows numbered stops on map
2. Click optimize → shows time savings
3. Apply optimization → reorders jobs
4. Jobs reflect new order

---

**End of Phase 2 Documentation**

Proceed to `PHASE3_SMS.md` after completing Phase 2.
