# TheWorx - Complete Build Guide

**For Claude Code Implementation**

---

## Project Overview

**TheWorx** is an end-to-end HVAC contractor platform that handles everything from estimate to install. Target users are small to large HVAC contractors (4-30 techs).

### Core Value Proposition
- **Duculator+**: Smart load calculator with regional climate data
- **Equipment Matcher**: Good/Better/Best equipment recommendations
- **Job Builder**: Complete job costing with margin visibility
- **Dispatch Board**: GPS-tracked technician scheduling
- **AI Enhancements**: Voice receptionist, photo analysis, smart routing

---

## Tech Stack

| Layer | Technology | Notes |
|-------|------------|-------|
| **Frontend Web** | React 18, Vite, TypeScript, Tailwind CSS | SPA with mobile-responsive design |
| **Frontend Mobile** | React Native (Expo) | iOS + Android |
| **Backend** | FastAPI (Python 3.11+) | Async with Pydantic v2 |
| **Database** | MongoDB Atlas | Motor async driver |
| **Auth** | JWT + bcrypt | Access + refresh tokens |
| **Maps/GPS** | Mapbox GL JS | Directions API for routing |
| **SMS** | Twilio | Programmable SMS |
| **Voice AI** | Twilio + ElevenLabs | Voice receptionist |
| **AI/LLM** | Claude API (Anthropic) | Summaries, analysis |
| **Vision AI** | Claude Vision | Photo analysis |
| **Transcription** | Whisper API (OpenAI) | Voice notes |
| **PDF Generation** | WeasyPrint | Quote PDFs |
| **Hosting** | Railway | Backend + Workers |
| **Frontend Hosting** | Vercel | Static deployment |
| **CI/CD** | GitHub Actions | Auto-deploy on merge |

---

## Project Structure

```
theworx/
├── README.md                    # This file
├── BUILD_GUIDE.md              # Phase-by-phase instructions
├── docker-compose.yml          # Local development
├── .env.example                # Environment template
├── .github/
│   └── workflows/
│       ├── backend.yml         # Backend CI/CD
│       └── frontend.yml        # Frontend CI/CD
│
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py             # FastAPI app entry
│   │   ├── config.py           # Settings/env vars
│   │   ├── database.py         # MongoDB connection
│   │   │
│   │   ├── api/
│   │   │   ├── __init__.py
│   │   │   ├── deps.py         # Dependencies (auth, db)
│   │   │   └── v1/
│   │   │       ├── __init__.py
│   │   │       ├── router.py   # Main router
│   │   │       ├── auth.py
│   │   │       ├── companies.py
│   │   │       ├── users.py
│   │   │       ├── customers.py
│   │   │       ├── jobs.py
│   │   │       ├── technicians.py
│   │   │       ├── equipment.py
│   │   │       ├── calculate.py
│   │   │       ├── schedule.py
│   │   │       ├── sms.py
│   │   │       └── ai.py
│   │   │
│   │   ├── models/
│   │   │   ├── __init__.py
│   │   │   ├── base.py         # Base model with id, timestamps
│   │   │   ├── user.py
│   │   │   ├── company.py
│   │   │   ├── customer.py
│   │   │   ├── job.py
│   │   │   ├── technician.py
│   │   │   ├── equipment.py
│   │   │   ├── sms.py
│   │   │   └── activity.py
│   │   │
│   │   ├── services/
│   │   │   ├── __init__.py
│   │   │   ├── auth_service.py
│   │   │   ├── load_calculator.py
│   │   │   ├── equipment_matcher.py
│   │   │   ├── pricing_engine.py
│   │   │   ├── quote_generator.py
│   │   │   ├── sms_service.py
│   │   │   ├── voice_service.py
│   │   │   ├── ai_service.py
│   │   │   ├── geocoding_service.py
│   │   │   └── routing_service.py
│   │   │
│   │   ├── core/
│   │   │   ├── __init__.py
│   │   │   ├── security.py     # JWT, password hashing
│   │   │   ├── exceptions.py   # Custom exceptions
│   │   │   └── constants.py    # Enums, constants
│   │   │
│   │   └── data/
│   │       ├── climate_zones.json
│   │       ├── equipment_seed.json
│   │       └── sms_templates.json
│   │
│   ├── tests/
│   │   ├── __init__.py
│   │   ├── conftest.py
│   │   ├── test_auth.py
│   │   ├── test_calculator.py
│   │   ├── test_jobs.py
│   │   └── test_scheduling.py
│   │
│   ├── requirements.txt
│   ├── Dockerfile
│   └── railway.toml
│
├── frontend/
│   ├── src/
│   │   ├── main.tsx
│   │   ├── App.tsx
│   │   ├── index.css
│   │   │
│   │   ├── api/
│   │   │   ├── client.ts       # Axios instance
│   │   │   ├── auth.ts
│   │   │   ├── customers.ts
│   │   │   ├── jobs.ts
│   │   │   ├── technicians.ts
│   │   │   ├── equipment.ts
│   │   │   ├── calculate.ts
│   │   │   └── schedule.ts
│   │   │
│   │   ├── components/
│   │   │   ├── ui/             # Shared UI components
│   │   │   │   ├── Button.tsx
│   │   │   │   ├── Input.tsx
│   │   │   │   ├── Card.tsx
│   │   │   │   ├── Modal.tsx
│   │   │   │   ├── Select.tsx
│   │   │   │   ├── Badge.tsx
│   │   │   │   ├── Table.tsx
│   │   │   │   └── Toast.tsx
│   │   │   │
│   │   │   ├── layout/
│   │   │   │   ├── Sidebar.tsx
│   │   │   │   ├── Header.tsx
│   │   │   │   ├── Layout.tsx
│   │   │   │   └── MobileNav.tsx
│   │   │   │
│   │   │   ├── duculator/
│   │   │   │   ├── PropertyForm.tsx
│   │   │   │   ├── LoadResults.tsx
│   │   │   │   ├── DuctSizing.tsx
│   │   │   │   └── index.ts
│   │   │   │
│   │   │   ├── equipment/
│   │   │   │   ├── EquipmentCard.tsx
│   │   │   │   ├── TierComparison.tsx
│   │   │   │   ├── EquipmentList.tsx
│   │   │   │   └── index.ts
│   │   │   │
│   │   │   ├── jobs/
│   │   │   │   ├── JobCard.tsx
│   │   │   │   ├── JobForm.tsx
│   │   │   │   ├── JobDetail.tsx
│   │   │   │   ├── LineItemEditor.tsx
│   │   │   │   ├── PriceBreakdown.tsx
│   │   │   │   ├── StatusBadge.tsx
│   │   │   │   └── index.ts
│   │   │   │
│   │   │   ├── customers/
│   │   │   │   ├── CustomerCard.tsx
│   │   │   │   ├── CustomerForm.tsx
│   │   │   │   ├── CustomerSearch.tsx
│   │   │   │   └── index.ts
│   │   │   │
│   │   │   ├── dispatch/
│   │   │   │   ├── DispatchBoard.tsx
│   │   │   │   ├── JobQueue.tsx
│   │   │   │   ├── TechCard.tsx
│   │   │   │   ├── MapView.tsx
│   │   │   │   ├── CalendarView.tsx
│   │   │   │   └── index.ts
│   │   │   │
│   │   │   └── settings/
│   │   │       ├── CompanySettings.tsx
│   │   │       ├── PricingSettings.tsx
│   │   │       ├── SMSTemplates.tsx
│   │   │       └── index.ts
│   │   │
│   │   ├── pages/
│   │   │   ├── Login.tsx
│   │   │   ├── Register.tsx
│   │   │   ├── Dashboard.tsx
│   │   │   ├── Duculator.tsx
│   │   │   ├── Jobs.tsx
│   │   │   ├── JobDetail.tsx
│   │   │   ├── Customers.tsx
│   │   │   ├── CustomerDetail.tsx
│   │   │   ├── Technicians.tsx
│   │   │   ├── Dispatch.tsx
│   │   │   ├── Equipment.tsx
│   │   │   ├── Settings.tsx
│   │   │   └── Reports.tsx
│   │   │
│   │   ├── hooks/
│   │   │   ├── useAuth.ts
│   │   │   ├── useJobs.ts
│   │   │   ├── useCustomers.ts
│   │   │   ├── useTechnicians.ts
│   │   │   ├── useEquipment.ts
│   │   │   ├── useWebSocket.ts
│   │   │   └── useGeolocation.ts
│   │   │
│   │   ├── context/
│   │   │   ├── AuthContext.tsx
│   │   │   ├── CompanyContext.tsx
│   │   │   └── ToastContext.tsx
│   │   │
│   │   ├── utils/
│   │   │   ├── format.ts       # Currency, dates, phone
│   │   │   ├── validation.ts
│   │   │   └── constants.ts
│   │   │
│   │   └── types/
│   │       ├── index.ts
│   │       ├── auth.ts
│   │       ├── customer.ts
│   │       ├── job.ts
│   │       ├── technician.ts
│   │       └── equipment.ts
│   │
│   ├── public/
│   │   └── favicon.ico
│   ├── index.html
│   ├── package.json
│   ├── tsconfig.json
│   ├── tailwind.config.js
│   ├── vite.config.ts
│   └── vercel.json
│
├── mobile/                     # Phase 4
│   ├── app/
│   ├── components/
│   ├── package.json
│   └── app.json
│
└── docs/
    ├── PHASE1_FOUNDATION.md
    ├── PHASE2_DISPATCH.md
    ├── PHASE3_SMS.md
    ├── PHASE4_MOBILE.md
    ├── PHASE5_AI_WAVE1.md
    ├── PHASE6_AI_WAVE2.md
    ├── PHASE7_PROCUREMENT.md
    ├── PHASE8_INTEGRATIONS.md
    ├── PHASE9_ANALYTICS.md
    ├── PHASE10_SCALE.md
    ├── API_REFERENCE.md
    ├── DATABASE_SCHEMA.md
    └── WIREFRAMES.md
```

---

## Environment Variables

```bash
# .env.example

# App
APP_NAME=TheWorx
APP_ENV=development
DEBUG=true
SECRET_KEY=your-secret-key-min-32-chars

# MongoDB
MONGODB_URL=mongodb+srv://user:pass@cluster.mongodb.net
MONGODB_DB_NAME=theworx_dev

# JWT
JWT_SECRET=your-jwt-secret-key
JWT_ALGORITHM=HS256
JWT_ACCESS_TOKEN_EXPIRE_MINUTES=30
JWT_REFRESH_TOKEN_EXPIRE_DAYS=7

# Twilio
TWILIO_ACCOUNT_SID=your-account-sid
TWILIO_AUTH_TOKEN=your-auth-token
TWILIO_PHONE_NUMBER=+1234567890

# ElevenLabs
ELEVENLABS_API_KEY=your-api-key
ELEVENLABS_VOICE_ID=your-voice-id

# Anthropic (Claude)
ANTHROPIC_API_KEY=your-api-key

# OpenAI (Whisper)
OPENAI_API_KEY=your-api-key

# Mapbox
MAPBOX_ACCESS_TOKEN=your-access-token

# Railway
RAILWAY_ENVIRONMENT=development
PORT=8000

# Frontend (Vite)
VITE_API_URL=http://localhost:8000
VITE_MAPBOX_TOKEN=your-access-token
```

---

## Phase Overview

| Phase | Name | Duration | Key Deliverables |
|-------|------|----------|------------------|
| 1 | Foundation | 6 weeks | Auth, Duculator, Equipment, Pricing, Jobs, Customers |
| 2 | Dispatch | 5 weeks | Tech management, Scheduler, GPS tracking, Map view |
| 3 | SMS | 3 weeks | Twilio integration, Auto-notifications, Templates |
| 4 | Mobile | 4 weeks | React Native app, Tech workflow, Background GPS |
| 5 | AI Wave 1 | 4 weeks | Voice receptionist, Voice notes, Smart dispatch |
| 6 | AI Wave 2 | 5 weeks | Photo analysis, Troubleshooting, Follow-up calls |
| 7 | Procurement | 4 weeks | Distributor pricing, Inventory, Purchase orders |
| 8 | Integrations | 3 weeks | Housecall Pro, QuickBooks, Zapier webhooks |
| 9 | Analytics | 3 weeks | Dashboards, Reports, AI insights |
| 10 | Scale | Ongoing | Performance, Security, Onboarding |

---

## Build Order for Claude Code

Each phase document contains:
1. **Goals** - What we're building and why
2. **Prerequisites** - What must exist first
3. **Files to Create** - Exact file paths and descriptions
4. **Wireframes** - ASCII mockups of UI
5. **API Specifications** - Endpoints with request/response
6. **Database Models** - MongoDB schemas
7. **Checklist** - Step-by-step implementation tasks
8. **Test Scenarios** - What to verify works
9. **Claude Code Prompts** - Copy-paste prompts to build each piece

---

## Getting Started

### Local Development Setup

```bash
# Clone repo
git clone https://github.com/yourorg/theworx.git
cd theworx

# Copy environment file
cp .env.example .env
# Edit .env with your credentials

# Start services
docker-compose up -d

# Backend
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload

# Frontend (new terminal)
cd frontend
npm install
npm run dev
```

### Railway Deployment

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# Create project
railway init

# Deploy backend
cd backend
railway up

# Set environment variables in Railway dashboard
```

---

## Next Steps

1. Read `docs/PHASE1_FOUNDATION.md` for detailed Phase 1 instructions
2. Start with project setup and authentication
3. Build Duculator core
4. Add equipment and pricing
5. Complete jobs and customers
6. Move to Phase 2

Each phase document is self-contained with everything Claude Code needs to implement that phase.
