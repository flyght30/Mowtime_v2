# Phase 3: SMS Communications

**Duration:** 3 weeks
**Prerequisites:** Phase 2 complete
**Goal:** Automated SMS notifications with Twilio

---

## 3.1 Goals

By end of Phase 3, contractors can:
- Send automated SMS when job is scheduled
- Send day-before reminder SMS
- Auto-send "tech enroute" and "15 min away" messages
- Send job completion SMS with invoice link
- Receive and view customer replies
- Customize SMS templates

---

## 3.2 Database Models

### SMSMessage
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "job_id": ObjectId | None,
  "customer_id": ObjectId,
  "tech_id": ObjectId | None,
  
  "direction": "outbound" | "inbound",
  "to_phone": str,
  "from_phone": str,
  "body": str,
  
  "trigger_type": "scheduled" | "reminder" | "enroute" | "15_min" | "arrived" | "complete" | "manual" | "reply",
  
  "status": "queued" | "sent" | "delivered" | "failed" | "received",
  "twilio_sid": str | None,
  "error_message": str | None,
  
  "sent_at": datetime | None,
  "delivered_at": datetime | None,
  "created_at": datetime,
}
```

### SMSTemplate
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "trigger_type": str,
  "name": str,
  "body": str,                    # With {{variables}}
  "is_active": bool,
  "is_default": bool,
  "created_at": datetime,
  "updated_at": datetime
}
```

### SMSSettings (in Company)
```python
{
  "sms": {
    "enabled": bool,
    "twilio_phone": str | None,
    "auto_scheduled": bool,       # Send when job scheduled
    "auto_reminder": bool,        # Day-before reminder
    "auto_enroute": bool,         # When tech marks enroute
    "auto_15_min": bool,          # 15 min ETA (GPS triggered)
    "auto_arrived": bool,         # When tech arrives
    "auto_complete": bool,        # When job complete
    "reminder_time": str,         # "18:00" evening before
    "opt_out_message": str
  }
}
```

---

## 3.3 Default SMS Templates

```json
{
  "scheduled": {
    "name": "Job Scheduled",
    "body": "Hi {{customer_first_name}}, your {{job_type}} with {{company_name}} is scheduled for {{scheduled_date}} at {{scheduled_time}}. Reply STOP to opt out."
  },
  "reminder": {
    "name": "Day Before Reminder",
    "body": "Reminder: {{company_name}} is scheduled to arrive tomorrow {{scheduled_date}} between {{scheduled_time}}. See you then!"
  },
  "enroute": {
    "name": "Tech Enroute",
    "body": "Your technician {{tech_first_name}} is on the way! Estimated arrival: {{eta_time}}."
  },
  "15_min": {
    "name": "15 Minutes Away",
    "body": "{{tech_first_name}} from {{company_name}} will arrive in about 15 minutes."
  },
  "arrived": {
    "name": "Tech Arrived",
    "body": "{{tech_first_name}} has arrived at your location. Thank you for choosing {{company_name}}!"
  },
  "complete": {
    "name": "Job Complete",
    "body": "Your service is complete! Invoice: {{invoice_link}}. Questions? Reply to this message or call {{company_phone}}."
  }
}
```

### Template Variables
- `{{customer_first_name}}` - Customer first name
- `{{customer_last_name}}` - Customer last name
- `{{company_name}}` - Company name
- `{{company_phone}}` - Company phone
- `{{job_type}}` - "installation" / "service call" / "maintenance"
- `{{scheduled_date}}` - "Monday, January 22"
- `{{scheduled_time}}` - "9:00 AM - 3:00 PM"
- `{{tech_first_name}}` - Technician first name
- `{{tech_phone}}` - Technician phone
- `{{eta_time}}` - "10:30 AM"
- `{{eta_minutes}}` - "15"
- `{{invoice_link}}` - Invoice URL
- `{{job_total}}` - "$11,462.00"

---

## 3.4 API Endpoints

### SMS

```
GET /api/v1/sms
Query: ?job_id=...&customer_id=...&direction=inbound
Response:
{
  "items": [
    {
      "id": "...",
      "direction": "outbound",
      "to_phone": "+15551234567",
      "body": "Your technician Mike is on the way!",
      "trigger_type": "enroute",
      "status": "delivered",
      "sent_at": "2025-01-22T10:30:00Z"
    }
  ],
  "total": 15
}

POST /api/v1/sms/send
Request:
{
  "customer_id": "...",
  "job_id": "...",
  "body": "Custom message here"
}
Response:
{
  "id": "...",
  "status": "sent",
  "twilio_sid": "SM..."
}

POST /api/v1/sms/webhook (Twilio callback)
Request: Twilio webhook payload
Response: TwiML or 200 OK
```

### SMS Templates

```
GET /api/v1/sms/templates
Response:
{
  "items": [
    {
      "id": "...",
      "trigger_type": "scheduled",
      "name": "Job Scheduled",
      "body": "Hi {{customer_first_name}}...",
      "is_active": true,
      "is_default": false
    }
  ]
}

PUT /api/v1/sms/templates/{id}
Request:
{
  "body": "Updated template text",
  "is_active": true
}
Response: Updated template

POST /api/v1/sms/templates/{id}/preview
Request:
{
  "job_id": "...",
  "customer_id": "..."
}
Response:
{
  "preview": "Hi John, your installation with ABC Heating is scheduled for..."
}

POST /api/v1/sms/templates/{id}/reset
Response: Reset to default template
```

### SMS Settings

```
GET /api/v1/company/sms-settings
Response: SMS settings object

PUT /api/v1/company/sms-settings
Request:
{
  "auto_scheduled": true,
  "auto_reminder": true,
  "auto_15_min": true,
  "reminder_time": "18:00"
}
Response: Updated settings
```

---

## 3.5 Wireframes

### SMS Settings Page
```
┌────────────────────────────────────────────────────────────────────────┐
│  Settings > SMS                                                        │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  [Company] [Pricing] [SMS] [Users] [Integrations]                     │
│                                                                        │
│  SMS Notifications                                    ┌──────────────┐ │
│  ─────────────────────────────────────────────────── │   Enabled    │ │
│                                                       └──────────────┘ │
│                                                                        │
│  Twilio Phone Number: +1 (555) 000-1234              [Change]         │
│                                                                        │
│  ═══════════════════════════════════════════════════════════════════  │
│                                                                        │
│  Automatic Messages                                                    │
│  ┌─────────────────────────────────────────────────────────────────┐  │
│  │                                                                 │  │
│  │  ☑ When job is scheduled                              [Edit]   │  │
│  │    "Hi {{customer_first_name}}, your installation..."          │  │
│  │                                                                 │  │
│  │  ☑ Day-before reminder                                [Edit]   │  │
│  │    Send at: [6:00 PM ▼] evening before                        │  │
│  │    "Reminder: ABC Heating is scheduled to arrive..."           │  │
│  │                                                                 │  │
│  │  ☑ When tech marks enroute                            [Edit]   │  │
│  │    "Your technician {{tech_first_name}} is on the way!"       │  │
│  │                                                                 │  │
│  │  ☑ 15 minutes before arrival (GPS)                    [Edit]   │  │
│  │    "{{tech_first_name}} will arrive in about 15 minutes."     │  │
│  │                                                                 │  │
│  │  ☐ When tech arrives                                  [Edit]   │  │
│  │    "{{tech_first_name}} has arrived at your location."        │  │
│  │                                                                 │  │
│  │  ☑ When job is complete                               [Edit]   │  │
│  │    "Your service is complete! Invoice: {{invoice_link}}"      │  │
│  │                                                                 │  │
│  └─────────────────────────────────────────────────────────────────┘  │
│                                                                        │
│                                            ┌─────────────────────┐    │
│                                            │    Save Changes     │    │
│                                            └─────────────────────┘    │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Edit Template Modal
```
┌─────────────────────────────────────────────────────────────────┐
│  Edit Template: Job Scheduled                            [✕]    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Message Template                                               │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Hi {{customer_first_name}}, your {{job_type}} with      │   │
│  │ {{company_name}} is scheduled for {{scheduled_date}}    │   │
│  │ at {{scheduled_time}}. Reply STOP to opt out.           │   │
│  │                                                         │   │
│  │                                                         │   │
│  └─────────────────────────────────────────────────────────┘   │
│  Characters: 156/160  │  1 segment                              │
│                                                                 │
│  Available Variables                                            │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ {{customer_first_name}}  {{scheduled_date}}             │   │
│  │ {{customer_last_name}}   {{scheduled_time}}             │   │
│  │ {{company_name}}         {{tech_first_name}}            │   │
│  │ {{company_phone}}        {{invoice_link}}               │   │
│  │ {{job_type}}             {{job_total}}                  │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Preview                                                        │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Hi John, your installation with ABC Heating & Air is    │   │
│  │ scheduled for Monday, January 22 at 9:00 AM - 3:00 PM. │   │
│  │ Reply STOP to opt out.                                  │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  [Reset to Default]                       [Cancel] [Save]       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### SMS Conversation View (Job Detail)
```
┌─────────────────────────────────────────────────────────────────┐
│  SMS History - John Smith                                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│                         Jan 21, 10:32 AM                        │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Hi John, your installation with ABC Heating & Air is    │ ← │
│  │ scheduled for Monday, January 22 at 9:00 AM - 3:00 PM. │   │
│  │ Reply STOP to opt out.                          ✓ Sent  │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│                         Jan 21, 6:00 PM                         │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Reminder: ABC Heating is scheduled to arrive tomorrow   │ ← │
│  │ January 22 between 9:00 AM - 3:00 PM.       ✓ Delivered │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│                         Jan 22, 8:45 AM                         │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Your technician Mike is on the way! Estimated arrival:  │ ← │
│  │ 9:15 AM.                                    ✓ Delivered │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Great, thanks for the heads up!                         │ → │
│  │                                              8:47 AM    │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│                         Jan 22, 9:00 AM                         │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Mike will arrive in about 15 minutes.       ✓ Delivered │ ← │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Type a message...                              [Send]   │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Incoming Messages Dashboard Widget
```
┌─────────────────────────────────────────────────────────────────┐
│  Recent Messages                                    [View All]  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ ● John Smith                                  8:47 AM   │   │
│  │   Great, thanks for the heads up!                       │   │
│  │   Job: JOB-2025-0045                          [Reply]   │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ ● Mary Jones                                Yesterday   │   │
│  │   Can we reschedule to Thursday?                        │   │
│  │   Job: JOB-2025-0044                          [Reply]   │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │   Bob Wilson                                 Jan 19     │   │
│  │   Sounds good                                           │   │
│  │   Job: JOB-2025-0043                          [View]    │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3.6 Implementation Checklist

### Sprint 7 (Week 13-14): Twilio Integration

#### Twilio Setup
- [ ] Create Twilio account
- [ ] Purchase phone number
- [ ] Configure webhook URLs
- [ ] Add credentials to environment

#### SMS Service
- [ ] Create `app/services/sms_service.py`:
  - [ ] Initialize Twilio client
  - [ ] `send_sms()` function
  - [ ] `process_webhook()` function
  - [ ] Template variable substitution
  - [ ] Opt-out handling
- [ ] Create SMSMessage model
- [ ] Create SMSTemplate model
- [ ] Seed default templates

#### SMS API
- [ ] Create `app/api/v1/sms.py`:
  - [ ] GET `/sms` - list messages
  - [ ] POST `/sms/send` - send manual message
  - [ ] POST `/sms/webhook` - Twilio callback
  - [ ] GET `/sms/templates` - list templates
  - [ ] PUT `/sms/templates/{id}` - update template
  - [ ] POST `/sms/templates/{id}/preview`
- [ ] Write tests

#### Automatic Triggers
- [ ] Hook into job.schedule → send scheduled SMS
- [ ] Create reminder scheduler (cron job)
- [ ] Hook into tech.status = enroute → send enroute SMS
- [ ] Hook into GPS 15-min proximity → send 15-min SMS
- [ ] Hook into tech.status = complete → send complete SMS

### Sprint 8 (Week 15): Frontend & Polish

#### Settings UI
- [ ] Create `src/pages/Settings/SMS.tsx`
- [ ] Toggle switches for each auto-message
- [ ] Template edit modals
- [ ] Variable insertion helper
- [ ] Character count and segment estimate
- [ ] Preview with sample data

#### Message UI
- [ ] Add SMS tab to Job Detail
- [ ] Create `src/components/sms/ConversationView.tsx`
- [ ] Create `src/components/sms/MessageBubble.tsx`
- [ ] Manual send input
- [ ] Status indicators (sent, delivered, failed)

#### Dashboard Widget
- [ ] Create `src/components/sms/RecentMessages.tsx`
- [ ] Show unread indicator
- [ ] Quick reply action
- [ ] Link to job

#### Notifications
- [ ] WebSocket for incoming messages
- [ ] Toast notification for new messages
- [ ] Unread badge in navigation

---

## 3.7 Claude Code Prompts

### Prompt 1: Twilio SMS Service
```
Build Twilio SMS integration for TheWorx:

Backend:
- SMS service with Twilio client
- Send SMS function with error handling
- Template variable substitution:
  {{customer_first_name}}, {{company_name}}, {{scheduled_date}}, etc.
- Webhook handler for delivery status updates
- Webhook handler for incoming messages
- Opt-out (STOP) handling
- Message logging to database

Models:
- SMSMessage: direction, phones, body, status, trigger_type, timestamps
- SMSTemplate: trigger_type, name, body, is_active

Environment:
- TWILIO_ACCOUNT_SID
- TWILIO_AUTH_TOKEN
- TWILIO_PHONE_NUMBER
```

### Prompt 2: Automatic SMS Triggers
```
Implement automatic SMS triggers:

1. Job Scheduled:
   - Trigger when job status changes to "scheduled"
   - Send immediately

2. Day-Before Reminder:
   - Background scheduler (APScheduler or Celery)
   - Run at configured time (default 6 PM)
   - Find jobs scheduled for next day
   - Send reminder SMS

3. Tech Enroute:
   - Trigger when tech status changes to "enroute"
   - Include ETA from routing service

4. 15 Minutes Away:
   - Check on each location update
   - Calculate distance/time to job
   - Send when ETA <= 15 minutes
   - Only send once per job

5. Job Complete:
   - Trigger when job status changes to "complete"
   - Include invoice link

Each trigger should:
- Check if auto-send is enabled in company settings
- Check if customer has SMS opt-in
- Use appropriate template
- Log message to database
```

### Prompt 3: SMS UI
```
Build SMS UI components:

Settings Page:
- Toggle for each auto-message type
- Edit template button → modal
- Template editor with variable picker
- Character count (160 per segment)
- Live preview with sample data
- Reset to default option

Job Detail SMS Tab:
- Conversation view (chat bubble style)
- Outbound messages on right (blue)
- Inbound messages on left (gray)
- Timestamp and status for each
- Manual message input at bottom
- Send button

Dashboard Widget:
- Recent incoming messages
- Unread indicator (dot)
- Customer name, message preview, time
- Link to job
- Quick reply button
```

---

## 3.8 Files to Create

```
backend/
├── app/
│   ├── api/v1/
│   │   └── sms.py              # NEW
│   ├── models/
│   │   └── sms.py              # NEW
│   ├── services/
│   │   └── sms_service.py      # NEW
│   ├── tasks/
│   │   ├── __init__.py         # NEW
│   │   └── sms_tasks.py        # NEW (reminders)
│   └── data/
│       └── sms_templates.json  # NEW

frontend/
├── src/
│   ├── components/
│   │   └── sms/
│   │       ├── ConversationView.tsx    # NEW
│   │       ├── MessageBubble.tsx       # NEW
│   │       ├── TemplateEditor.tsx      # NEW
│   │       ├── RecentMessages.tsx      # NEW
│   │       └── index.ts                # NEW
│   ├── pages/
│   │   └── Settings/
│   │       └── SMS.tsx                 # NEW
│   └── api/
│       └── sms.ts                      # NEW
```

---

## 3.9 Test Scenarios

### SMS Sending
1. Send manual SMS → message delivered, logged
2. Send to opted-out customer → message blocked
3. Invalid phone number → error handled gracefully
4. Twilio error → retry logic, error logged

### Automatic Triggers
1. Schedule job → SMS sent immediately
2. 6 PM day before → reminder sent
3. Tech marks enroute → SMS with ETA sent
4. GPS shows 15 min away → SMS sent (once only)
5. Job complete → SMS with invoice sent

### Templates
1. Edit template → preview updates
2. Add variable → inserted at cursor
3. Reset template → returns to default
4. Character count → accurate per segment

### Incoming Messages
1. Customer replies → message logged
2. Customer sends STOP → opted out, confirmed
3. New message → toast notification appears
4. View conversation → all messages shown

---

**End of Phase 3 Documentation**

Proceed to `PHASE4_MOBILE.md` after completing Phase 3.
