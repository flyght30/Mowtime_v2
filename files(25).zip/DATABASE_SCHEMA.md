# TheWorx - Database Schema Reference

**Database:** MongoDB
**Driver:** Motor (async)
**ODM:** Pydantic v2

---

## Core Collections

### users
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "email": str,                      # Unique, indexed
  "password_hash": str,
  "first_name": str,
  "last_name": str,
  "phone": str | None,
  "role": "owner" | "admin" | "dispatcher" | "tech",
  "tech_id": ObjectId | None,        # Link to technician if role=tech
  "is_active": bool,
  "last_login": datetime | None,
  "created_at": datetime,
  "updated_at": datetime
}

Indexes:
- email (unique)
- company_id
```

### companies
```python
{
  "_id": ObjectId,
  "name": str,
  "phone": str,
  "email": str,
  "address": str,
  "city": str,
  "state": str,
  "zip_code": str,
  "logo_url": str | None,
  
  "settings": {
    "labor_rate_install": float,     # Default: 85.00
    "labor_rate_helper": float,      # Default: 45.00
    "overhead_percentage": float,    # Default: 0.15
    "profit_percentage": float,      # Default: 0.20
    "default_job_duration": float,   # Default: 6.0
    "timezone": str                  # Default: "America/Chicago"
  },
  
  "sms": {
    "enabled": bool,
    "twilio_phone": str | None,
    "auto_scheduled": bool,
    "auto_reminder": bool,
    "auto_enroute": bool,
    "auto_15_min": bool,
    "auto_arrived": bool,
    "auto_complete": bool,
    "reminder_time": str             # "18:00"
  },
  
  "subscription": {
    "tier": "starter" | "pro" | "business" | "enterprise",
    "tech_limit": int,
    "stripe_customer_id": str | None,
    "stripe_subscription_id": str | None,
    "expires_at": datetime | None
  },
  
  "created_at": datetime,
  "updated_at": datetime
}
```

### customers
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,            # Indexed
  "first_name": str,
  "last_name": str,
  "phone": str,                      # Indexed
  "email": str | None,
  "address": str,
  "city": str,
  "state": str,
  "zip_code": str,
  
  "location": {                      # 2dsphere indexed
    "type": "Point",
    "coordinates": [float, float]    # [lng, lat]
  },
  
  "sms_opt_in": bool,
  "notes": str | None,
  
  "stats": {
    "job_count": int,
    "total_revenue": float,
    "last_job_date": datetime | None,
    "no_show_count": int,
    "avg_rating": float | None
  },
  
  "created_at": datetime,
  "updated_at": datetime
}

Indexes:
- company_id
- phone
- location (2dsphere)
- company_id + last_name
```

### technicians
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "user_id": ObjectId | None,
  "first_name": str,
  "last_name": str,
  "phone": str,
  "email": str | None,
  
  "status": "available" | "assigned" | "enroute" | "on_site" | "complete" | "off_duty",
  "current_job_id": ObjectId | None,
  "next_job_id": ObjectId | None,
  
  "location": {
    "type": "Point",
    "coordinates": [float, float],
    "timestamp": datetime,
    "accuracy": float | None
  },
  
  "certifications": [str],
  "skills": {
    "can_install": bool,
    "can_service": bool,
    "can_maintenance": bool
  },
  
  "schedule": {
    "work_days": [int],              # 0=Sun, 1=Mon, etc.
    "start_time": str,
    "end_time": str,
    "lunch_start": str,
    "lunch_duration": int
  },
  
  "stats": {
    "jobs_completed": int,
    "avg_rating": float | None,
    "on_time_percentage": float,
    "efficiency_ratio": float        # actual/estimated time
  },
  
  "is_active": bool,
  "created_at": datetime,
  "updated_at": datetime
}

Indexes:
- company_id
- status
- location (2dsphere)
```

### equipment
```python
{
  "_id": ObjectId,
  "brand": str,
  "model": str,
  "tier": "good" | "better" | "best",
  "tons": float,
  "seer": float,
  "cfm": int,
  
  "cost": float,
  "msrp": float,
  
  "warranty": {
    "parts_years": int,
    "labor_years": int,
    "compressor_years": int,
    "description": str
  },
  
  "distributor": str,
  "part_number": str | None,
  "in_stock": bool,
  "lead_time_days": int,
  
  "updated_at": datetime
}

Indexes:
- brand + tons
- tier + tons
```

### jobs
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "customer_id": ObjectId,
  "job_number": str,                 # Unique per company
  "job_type": "install" | "service" | "maintenance" | "estimate",
  "status": "draft" | "quoted" | "approved" | "scheduled" | "in_progress" | "complete" | "invoiced" | "paid" | "cancelled",
  
  "property": {
    "zip_code": str,
    "sqft": int,
    "sun_exposure": "shady" | "partial" | "full",
    "occupancy": int,
    "ceiling_height": float,
    "insulation": "poor" | "average" | "good",
    "window_percentage": int,
    "floors": int,
    "year_built": int | None
  },
  
  "load_calculation": {
    "btu": int,
    "tons": float,
    "cfm": int
  },
  
  "duct_sizing": {
    "supply_outlets": int,
    "return_size": str,
    "trunk_size": str,
    "branch_size": str
  },
  
  "climate": {
    "region": str,
    "humidity": float,
    "design_temp": int
  },
  
  "equipment_id": ObjectId | None,
  "selected_tier": "good" | "better" | "best" | None,
  
  "line_items": [
    {
      "id": str,
      "description": str,
      "category": "equipment" | "materials" | "labor" | "other",
      "quantity": float,
      "unit_price": float,
      "total": float
    }
  ],
  
  "pricing": {
    "equipment": float,
    "materials": float,
    "labor": float,
    "subtotal": float,
    "overhead": float,
    "profit": float,
    "total": float,
    "margin_percentage": float
  },
  
  "schedule": {
    "scheduled_date": date | None,
    "scheduled_time_start": str | None,
    "scheduled_time_end": str | None,
    "tech_id": ObjectId | None,
    "estimated_hours": float,
    "schedule_entry_id": ObjectId | None
  },
  
  "tracking": {
    "assigned_at": datetime | None,
    "enroute_at": datetime | None,
    "arrived_at": datetime | None,
    "started_at": datetime | None,
    "completed_at": datetime | None,
    "travel_time_minutes": int | None,
    "job_duration_minutes": int | None
  },
  
  "completion": {
    "tech_notes": str | None,
    "photos": [str],
    "signature_url": str | None,
    "checklist": dict | None,
    "materials_used": [
      { "item_id": ObjectId, "quantity": float, "cost": float }
    ]
  },
  
  "costing": {
    "estimated": {
      "equipment": float,
      "materials": float,
      "labor_hours": float,
      "labor_cost": float,
      "total": float
    },
    "actual": {
      "equipment": float,
      "materials": float,
      "labor_hours": float,
      "labor_cost": float,
      "total": float
    },
    "variance": {
      "equipment": float,
      "materials": float,
      "labor": float,
      "total": float,
      "percentage": float
    }
  },
  
  "no_show_risk": {
    "score": float | None,
    "factors": [str] | None,
    "calculated_at": datetime | None
  },
  
  "created_at": datetime,
  "updated_at": datetime
}

Indexes:
- company_id
- company_id + status
- company_id + job_number (unique)
- customer_id
- schedule.tech_id + schedule.scheduled_date
- status
```

### schedule_entries
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "tech_id": ObjectId,
  "job_id": ObjectId,
  "date": date,
  "start_time": str,
  "end_time": str,
  "estimated_hours": float,
  "status": "scheduled" | "in_progress" | "complete" | "cancelled",
  "order": int,
  "travel_time_minutes": int | None,
  "created_at": datetime,
  "updated_at": datetime
}

Indexes:
- company_id + date
- tech_id + date
- job_id
```

### tech_locations
```python
{
  "_id": ObjectId,
  "tech_id": ObjectId,
  "company_id": ObjectId,
  "location": {
    "type": "Point",
    "coordinates": [float, float]
  },
  "accuracy": float | None,
  "timestamp": datetime
}

Indexes:
- tech_id + timestamp
- timestamp (TTL: 7 days)
```

### sms_messages
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "job_id": ObjectId | None,
  "customer_id": ObjectId,
  "tech_id": ObjectId | None,
  
  "direction": "outbound" | "inbound",
  "to_phone": str,
  "from_phone": str,
  "body": str,
  
  "trigger_type": "scheduled" | "reminder" | "enroute" | "15_min" | "arrived" | "complete" | "manual" | "reply",
  
  "status": "queued" | "sent" | "delivered" | "failed" | "received",
  "twilio_sid": str | None,
  "error_message": str | None,
  
  "sent_at": datetime | None,
  "delivered_at": datetime | None,
  "created_at": datetime
}

Indexes:
- company_id
- job_id
- customer_id
- direction + created_at
```

### sms_templates
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "trigger_type": str,
  "name": str,
  "body": str,
  "is_active": bool,
  "is_default": bool,
  "created_at": datetime,
  "updated_at": datetime
}

Indexes:
- company_id + trigger_type
```

### voice_calls
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "customer_id": ObjectId | None,
  "job_id": ObjectId | None,
  
  "direction": "inbound" | "outbound",
  "from_phone": str,
  "to_phone": str,
  
  "twilio_call_sid": str,
  "status": "ringing" | "in_progress" | "completed" | "failed" | "no_answer",
  "duration_seconds": int,
  
  "handled_by": "ai" | "human" | "voicemail",
  "ai_outcome": "appointment_booked" | "status_inquiry" | "reschedule" | "cancel" | "transfer" | "message" | None,
  
  "transcript": str | None,
  "summary": str | None,
  "recording_url": str | None,
  
  "created_at": datetime,
  "ended_at": datetime | None
}

Indexes:
- company_id
- twilio_call_sid
- from_phone
```

### voice_notes
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "job_id": ObjectId,
  "tech_id": ObjectId,
  
  "audio_url": str,
  "duration_seconds": int,
  
  "transcription": str | None,
  "summary": str | None,
  
  "status": "uploaded" | "transcribing" | "summarizing" | "complete" | "failed",
  "error": str | None,
  
  "created_at": datetime,
  "processed_at": datetime | None
}

Indexes:
- job_id
- tech_id
```

### distributors
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "name": str,
  "contact_name": str | None,
  "email": str,
  "phone": str,
  "account_number": str | None,
  "address": str,
  "price_list_updated": datetime | None,
  "is_active": bool,
  "created_at": datetime
}

Indexes:
- company_id
```

### pricelist_items
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "distributor_id": ObjectId,
  
  "part_number": str,
  "description": str,
  "category": "equipment" | "parts" | "materials" | "refrigerant" | "other",
  
  "cost": float,
  "msrp": float | None,
  "unit": str,
  
  "brand": str | None,
  "model": str | None,
  
  "in_stock": bool,
  "lead_time_days": int | None,
  
  "effective_date": date,
  "expires_date": date | None,
  
  "updated_at": datetime
}

Indexes:
- company_id + distributor_id
- part_number
- brand + model
```

### inventory_items
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  
  "name": str,
  "part_number": str | None,
  "category": str,
  "unit": str,
  
  "quantity_on_hand": float,
  "reorder_point": float,
  "reorder_quantity": float,
  
  "cost_per_unit": float,
  "last_cost": float,
  
  "location": str | None,
  
  "updated_at": datetime
}

Indexes:
- company_id
- company_id + category
```

### inventory_transactions
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "item_id": ObjectId,
  
  "type": "adjustment" | "usage" | "received" | "transfer",
  "quantity": float,
  "job_id": ObjectId | None,
  "po_id": ObjectId | None,
  
  "notes": str | None,
  "user_id": ObjectId,
  "created_at": datetime
}

Indexes:
- item_id
- company_id + created_at
```

### purchase_orders
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "distributor_id": ObjectId,
  
  "po_number": str,
  "job_id": ObjectId | None,
  
  "status": "draft" | "pending_approval" | "approved" | "sent" | "partial" | "received" | "cancelled",
  
  "items": [
    {
      "part_number": str,
      "description": str,
      "quantity": float,
      "unit_cost": float,
      "total": float,
      "received_quantity": float
    }
  ],
  
  "subtotal": float,
  "tax": float,
  "total": float,
  
  "notes": str | None,
  "sent_at": datetime | None,
  "received_at": datetime | None,
  
  "created_by": ObjectId,
  "approved_by": ObjectId | None,
  "created_at": datetime,
  "updated_at": datetime
}

Indexes:
- company_id
- company_id + po_number (unique)
- status
```

### integrations
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "provider": "housecall_pro" | "quickbooks" | "google_calendar",
  
  "is_active": bool,
  "connected_at": datetime,
  
  "credentials": {
    "access_token": str,             # Encrypted
    "refresh_token": str,            # Encrypted
    "expires_at": datetime,
    "account_id": str | None
  },
  
  "settings": dict,
  
  "sync_status": {
    "last_sync": datetime | None,
    "last_error": str | None,
    "items_synced": int
  },
  
  "created_at": datetime,
  "updated_at": datetime
}

Indexes:
- company_id + provider (unique)
```

### sync_mappings
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "integration_id": ObjectId,
  
  "local_type": "customer" | "job" | "invoice",
  "local_id": ObjectId,
  "remote_id": str,
  
  "last_synced": datetime,
  "sync_direction": "push" | "pull" | "bidirectional",
  
  "created_at": datetime
}

Indexes:
- integration_id + local_type + local_id
- integration_id + remote_id
```

### webhook_subscriptions
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  
  "url": str,
  "events": [str],
  "secret": str,
  
  "is_active": bool,
  "last_triggered": datetime | None,
  "failure_count": int,
  
  "created_at": datetime
}

Indexes:
- company_id
```

### webhook_logs
```python
{
  "_id": ObjectId,
  "subscription_id": ObjectId,
  
  "event": str,
  "payload": dict,
  "response_status": int | None,
  "response_body": str | None,
  "error": str | None,
  
  "created_at": datetime
}

Indexes:
- subscription_id + created_at
- created_at (TTL: 30 days)
```

### activity_logs
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "user_id": ObjectId | None,
  
  "entity_type": str,
  "entity_id": ObjectId,
  "action": str,
  "changes": dict | None,
  "ip_address": str | None,
  
  "created_at": datetime
}

Indexes:
- company_id + entity_type + entity_id
- created_at (TTL: 90 days)
```

---

## Index Summary

**Performance-Critical Indexes:**
1. `jobs.company_id + status` - Job filtering
2. `jobs.schedule.tech_id + schedule.scheduled_date` - Daily schedule
3. `customers.company_id + location` - Nearby customer search
4. `technicians.company_id + status` - Available tech lookup
5. `sms_messages.job_id` - Message history

**TTL Indexes:**
1. `tech_locations.timestamp` - 7 days
2. `webhook_logs.created_at` - 30 days
3. `activity_logs.created_at` - 90 days

---

## Data Relationships

```
Company
  ├── Users
  ├── Technicians
  ├── Customers
  │     └── Jobs
  │           ├── Schedule Entries
  │           ├── SMS Messages
  │           ├── Voice Notes
  │           └── Purchase Orders
  ├── Equipment (shared reference)
  ├── Distributors
  │     └── Pricelist Items
  ├── Inventory Items
  │     └── Inventory Transactions
  ├── Integrations
  │     └── Sync Mappings
  ├── Webhook Subscriptions
  │     └── Webhook Logs
  └── Activity Logs
```
