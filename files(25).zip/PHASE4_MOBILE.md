# Phase 4: Mobile App

**Duration:** 4 weeks
**Prerequisites:** Phase 3 complete
**Goal:** React Native tech app with full job workflow

---

## 4.1 Goals

By end of Phase 4, technicians can:
- Login to mobile app
- View today's jobs and route
- Update status (enroute, arrived, complete)
- Navigate to job site
- View job and customer details
- Capture completion photos
- Get customer signature
- Submit job completion notes

---

## 4.2 Tech Stack

- **Framework:** React Native with Expo
- **Navigation:** React Navigation
- **State:** React Query + Zustand
- **Maps:** React Native Maps (Mapbox)
- **Camera:** Expo Camera
- **Signature:** react-native-signature-canvas
- **Location:** Expo Location (background)
- **Push:** Expo Notifications

---

## 4.3 Screens

### Login
```
┌─────────────────────────────────┐
│                                 │
│         ┌──────────┐            │
│         │    W     │            │
│         │ TheWorx  │            │
│         └──────────┘            │
│                                 │
│      ┌─────────────────────┐    │
│      │ Email               │    │
│      └─────────────────────┘    │
│                                 │
│      ┌─────────────────────┐    │
│      │ Password            │    │
│      └─────────────────────┘    │
│                                 │
│      ┌─────────────────────┐    │
│      │      Sign In        │    │
│      └─────────────────────┘    │
│                                 │
└─────────────────────────────────┘
```

### Today's Jobs (Home)
```
┌─────────────────────────────────┐
│ Today, Jan 22          ● Online │
├─────────────────────────────────┤
│                                 │
│  Current Job                    │
│  ┌───────────────────────────┐  │
│  │ ● ENROUTE                 │  │
│  │                           │  │
│  │ John Smith                │  │
│  │ 123 Main St, Auburn       │  │
│  │ Install 3.5T Am Std       │  │
│  │                           │  │
│  │ ETA: 8 minutes            │  │
│  │                           │  │
│  │ ┌─────────┐ ┌───────────┐ │  │
│  │ │  Call   │ │ Navigate  │ │  │
│  │ └─────────┘ └───────────┘ │  │
│  │                           │  │
│  │    [ Mark Arrived ]       │  │
│  └───────────────────────────┘  │
│                                 │
│  Next                           │
│  ┌───────────────────────────┐  │
│  │ Mary Jones • 3:00 PM      │  │
│  │ 456 Oak Ave • Service     │  │
│  └───────────────────────────┘  │
│                                 │
│  Route: 2 jobs • 45 min drive   │
│                                 │
├─────────────────────────────────┤
│  [Home]    [Jobs]    [Profile]  │
└─────────────────────────────────┘
```

### Job Detail
```
┌─────────────────────────────────┐
│ ← Back                    ● ● ● │
├─────────────────────────────────┤
│                                 │
│  John Smith                     │
│  📞 (555) 123-4567              │
│  📍 123 Main Street             │
│     Auburn, AL 36830            │
│                                 │
│  ┌─────────┐ ┌─────────┐        │
│  │  Call   │ │  Text   │        │
│  └─────────┘ └─────────┘        │
│                                 │
│  ─────────────────────────────  │
│                                 │
│  System Details                 │
│  ┌───────────────────────────┐  │
│  │ Type: Installation        │  │
│  │ Equipment: Am Std Silver  │  │
│  │ Size: 3.5 Ton            │  │
│  │ SEER: 15                  │  │
│  │                           │  │
│  │ Outlets: 14               │  │
│  │ Return: 20x25             │  │
│  │ Trunk: 12x20              │  │
│  └───────────────────────────┘  │
│                                 │
│  Notes                          │
│  ┌───────────────────────────┐  │
│  │ Customer mentioned noise  │  │
│  │ from existing unit.       │  │
│  │ Check compressor.         │  │
│  └───────────────────────────┘  │
│                                 │
│  History (2 previous jobs)      │
│  ┌───────────────────────────┐  │
│  │ Jun 2024 - Maintenance    │  │
│  │ Jan 2024 - Service call   │  │
│  └───────────────────────────┘  │
│                                 │
├─────────────────────────────────┤
│      [ Start Job ]              │
└─────────────────────────────────┘
```

### Active Job (On Site)
```
┌─────────────────────────────────┐
│ ← Back            Timer: 2:34:15│
├─────────────────────────────────┤
│                                 │
│  ● ON SITE                      │
│  John Smith • 123 Main St       │
│                                 │
│  ─────────────────────────────  │
│                                 │
│  Quick Actions                  │
│  ┌─────────┐ ┌─────────┐        │
│  │  Call   │ │  Text   │        │
│  │ Customer│ │ Office  │        │
│  └─────────┘ └─────────┘        │
│                                 │
│  ─────────────────────────────  │
│                                 │
│  Job Checklist                  │
│  ☑ Old unit removed             │
│  ☑ New unit installed           │
│  ☑ Refrigerant charged          │
│  ☑ Electrical connected         │
│  ☐ Thermostat programmed        │
│  ☐ Customer walkthrough         │
│                                 │
│  ─────────────────────────────  │
│                                 │
│  Notes                          │
│  ┌───────────────────────────┐  │
│  │ Found corroded wiring in  │  │
│  │ disconnect box. Replaced. │  │
│  │                      Edit │  │
│  └───────────────────────────┘  │
│                                 │
├─────────────────────────────────┤
│      [ Complete Job ]           │
└─────────────────────────────────┘
```

### Job Completion
```
┌─────────────────────────────────┐
│ ← Back              Complete Job│
├─────────────────────────────────┤
│                                 │
│  Photos (required)              │
│  ┌─────┐ ┌─────┐ ┌─────┐       │
│  │ 📷  │ │ 📷  │ │  +  │       │
│  │ Old │ │ New │ │ Add │       │
│  └─────┘ └─────┘ └─────┘       │
│                                 │
│  ─────────────────────────────  │
│                                 │
│  Completion Notes               │
│  ┌───────────────────────────┐  │
│  │ Installed new 3.5 ton Am  │  │
│  │ Std unit. Found corroded  │  │
│  │ wiring in disconnect,     │  │
│  │ replaced. All functions   │  │
│  │ tested and working.       │  │
│  │                      🎤   │  │
│  └───────────────────────────┘  │
│  [🎤 Voice Note]                │
│                                 │
│  ─────────────────────────────  │
│                                 │
│  Materials Used                 │
│  ☑ Line set (30ft)              │
│  ☑ Refrigerant (4 lbs)          │
│  ☑ Disconnect box               │
│  ☐ Add item...                  │
│                                 │
│  ─────────────────────────────  │
│                                 │
│  Customer Signature             │
│  ┌───────────────────────────┐  │
│  │                           │  │
│  │     ~ John Smith ~        │  │
│  │                           │  │
│  │                    Clear  │  │
│  └───────────────────────────┘  │
│                                 │
├─────────────────────────────────┤
│      [ Submit & Complete ]      │
└─────────────────────────────────┘
```

### Route View
```
┌─────────────────────────────────┐
│ ← Back              Today's Route│
├─────────────────────────────────┤
│                                 │
│  ┌───────────────────────────┐  │
│  │                           │  │
│  │      [MAP WITH ROUTE]     │  │
│  │                           │  │
│  │   🏠 → ① → ② → 🏠        │  │
│  │                           │  │
│  └───────────────────────────┘  │
│                                 │
│  Total: 45 min drive • 2 jobs   │
│                                 │
│  ─────────────────────────────  │
│                                 │
│  ① 9:00 AM                      │
│  ┌───────────────────────────┐  │
│  │ John Smith                │  │
│  │ 123 Main St               │  │
│  │ Install • 6 hrs           │  │
│  │                 [Navigate]│  │
│  └───────────────────────────┘  │
│                                 │
│  ↓ 15 min drive                 │
│                                 │
│  ② 3:00 PM                      │
│  ┌───────────────────────────┐  │
│  │ Mary Jones                │  │
│  │ 456 Oak Ave               │  │
│  │ Service • 1.5 hrs         │  │
│  │                 [Navigate]│  │
│  └───────────────────────────┘  │
│                                 │
└─────────────────────────────────┘
```

---

## 4.4 API Additions

```
# Tech-specific endpoints

GET /api/v1/tech/me
Response: Current tech profile with today's jobs

GET /api/v1/tech/jobs/today
Response: Today's jobs in route order

PATCH /api/v1/tech/jobs/{id}/status
Request: { "status": "arrived" }
Response: Updated job with timestamps

POST /api/v1/tech/jobs/{id}/complete
Request: {
  "notes": "...",
  "photos": ["base64...", "base64..."],
  "signature": "base64...",
  "materials_used": ["line_set", "refrigerant"],
  "checklist": { "old_removed": true, ... }
}
Response: Completed job

POST /api/v1/tech/location
Request: { "lat": 32.6099, "lng": -85.4808 }
Response: { "received": true }
```

---

## 4.5 Implementation Checklist

### Sprint 9 (Week 16-17): App Shell & Auth

- [ ] Initialize Expo project
- [ ] Setup React Navigation (stack + tabs)
- [ ] Create auth flow (login, token storage)
- [ ] Create API client with token refresh
- [ ] Setup Zustand for state management
- [ ] Create basic theme and components
- [ ] Create Home screen shell
- [ ] Create Jobs list screen shell

### Sprint 10 (Week 18-19): Core Features

- [ ] Implement job list with today's jobs
- [ ] Implement job detail screen
- [ ] Status update buttons (enroute, arrived)
- [ ] Phone call integration
- [ ] Navigation to address (open maps app)
- [ ] Route view with map
- [ ] Background location tracking
- [ ] Location permission handling

### Sprint 11 (Week 20): Completion Flow

- [ ] Photo capture with Expo Camera
- [ ] Photo preview and retake
- [ ] Completion notes input
- [ ] Voice recording (optional)
- [ ] Materials checklist
- [ ] Signature capture
- [ ] Submit completion flow
- [ ] Offline queue for poor connectivity
- [ ] Push notifications setup

---

## 4.6 Files to Create

```
mobile/
├── app/
│   ├── (auth)/
│   │   ├── login.tsx
│   │   └── _layout.tsx
│   ├── (tabs)/
│   │   ├── index.tsx           # Home/Today
│   │   ├── jobs.tsx            # All Jobs
│   │   ├── profile.tsx         # Profile
│   │   └── _layout.tsx
│   ├── job/
│   │   ├── [id].tsx            # Job Detail
│   │   └── complete/[id].tsx   # Completion
│   ├── route.tsx               # Route View
│   └── _layout.tsx
├── components/
│   ├── JobCard.tsx
│   ├── StatusButton.tsx
│   ├── PhotoCapture.tsx
│   ├── SignaturePad.tsx
│   ├── VoiceRecorder.tsx
│   └── ui/
├── hooks/
│   ├── useAuth.ts
│   ├── useJobs.ts
│   ├── useLocation.ts
│   └── useOfflineQueue.ts
├── services/
│   ├── api.ts
│   ├── location.ts
│   └── notifications.ts
├── store/
│   ├── auth.ts
│   └── jobs.ts
├── app.json
├── package.json
└── tsconfig.json
```

---

## 4.7 Claude Code Prompts

### Prompt 1: Expo Setup
```
Initialize React Native app with Expo for TheWorx tech app:

- Expo SDK 50+
- TypeScript
- Expo Router for navigation
- Tab navigation: Home, Jobs, Profile
- Stack navigation for job detail and completion
- Theme with TheWorx colors (orange #f97316, dark slate)
- Basic UI components (Button, Card, Input)
- Auth flow with secure token storage
```

### Prompt 2: Job Screens
```
Build job screens for tech app:

Home Screen:
- Today's date header
- Current job card (large, prominent)
- Status badge with color
- Action buttons: Call, Navigate
- Status change button
- Next job preview
- Total route summary

Job Detail Screen:
- Customer info with call/text buttons
- Address with navigate button
- System details (equipment, sizing)
- Job notes
- Previous job history
- Start Job / Mark Arrived button

Jobs List Screen:
- Upcoming jobs list
- Past jobs (last 7 days)
- Pull to refresh
- Job cards with status
```

### Prompt 3: Completion Flow
```
Build job completion flow:

Photo Capture:
- Camera view with capture button
- Minimum 2 photos required
- Photo preview grid
- Delete/retake option
- Photo labels (before, after, equipment)

Completion Form:
- Notes text area
- Voice recording option (transcribe later)
- Materials used checklist
- Custom item addition
- Signature pad (react-native-signature-canvas)
- Clear signature button

Submit:
- Validation (photos required, signature required)
- Loading state
- Success confirmation
- Navigate to next job or home
- Offline queue if no connection
```

### Prompt 4: Background Location
```
Implement background location tracking:

- Request permissions (foreground + background)
- Track location every 2 minutes when on duty
- Send to /tech/location endpoint
- Battery optimization (significant changes mode)
- Pause when off duty
- Handle permission denial gracefully
- Show location indicator in header
```

---

**End of Phase 4 Documentation**

Proceed to `PHASE5_AI_WAVE1.md` after completing Phase 4.
