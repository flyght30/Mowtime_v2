# Phase 6: AI Wave 2

**Duration:** 5 weeks
**Prerequisites:** Phase 5 complete
**Goal:** Photo AI analysis, troubleshooting assistant, automated follow-ups

---

## 6.1 Goals

By end of Phase 6, contractors can:
- Upload home exterior photo → auto-populate estimate inputs
- Tech photographs equipment → AI identifies brand/model/issues
- Tech describes problem → AI suggests diagnostic steps
- AI makes post-job follow-up calls
- Happy customers get review request with pre-filled text

---

## 6.2 Features

### Photo → Estimate

**Input:** Exterior home photo from tech or customer
**AI Analysis (Claude Vision):**
- Estimate square footage from structure
- Detect sun exposure (tree coverage, orientation)
- Count visible windows
- Identify roof type
- Estimate home age/construction era
- Note visible HVAC equipment

**Output:** Pre-filled Duculator inputs with confidence scores

### Equipment Photo Analysis

**Input:** Photo of existing HVAC equipment
**AI Analysis:**
- Identify brand from nameplate/logo
- Read model number if visible
- Estimate age from style/wear
- Spot visible issues (rust, damage, leaks)
- Suggest common problems for that model

**Output:** Equipment profile with maintenance suggestions

### Troubleshooting Assistant

**Input:** Tech describes symptom (voice or text)
**AI Provides:**
- Diagnostic steps in order
- Common causes ranked by likelihood
- Error code lookup (if code mentioned)
- Parts that may be needed
- Safety warnings if applicable
- Links to manufacturer resources

### Post-Job Follow-Up

**Trigger:** 24 hours after job completion
**AI Call:**
- "Hi, this is Clara from ABC Heating..."
- "How is everything working?"
- Collect feedback (1-5 rating)
- If happy → ask for Google review
- If issues → route to dispatcher
- Log outcome

### Review Generation

**For happy customers:**
- Generate personalized review text based on job
- Include: tech name, service type, highlights
- One-click copy to clipboard
- Direct link to Google review page

---

## 6.3 API Endpoints

### Photo Analysis

```
POST /api/v1/ai/analyze-property
Request: multipart/form-data with image
Response: {
  "analysis": {
    "sqft_estimate": 2400,
    "sqft_confidence": 0.75,
    "sun_exposure": "partial",
    "sun_confidence": 0.85,
    "window_percentage": 15,
    "window_confidence": 0.70,
    "roof_type": "shingle",
    "home_age": "1990s",
    "visible_equipment": "condensing unit on north side",
    "notes": "Two-story home with mature trees providing afternoon shade"
  },
  "suggested_inputs": {
    "sqft": 2400,
    "sun_exposure": "partial",
    "window_percentage": 15,
    "insulation": "average"
  }
}

POST /api/v1/ai/analyze-equipment
Request: multipart/form-data with image
Response: {
  "equipment": {
    "brand": "Carrier",
    "model": "24ACC636A003",
    "type": "condensing_unit",
    "estimated_age": "12-15 years",
    "tonnage": "3 ton",
    "condition": "fair",
    "visible_issues": [
      "Surface rust on cabinet",
      "Debris around unit"
    ]
  },
  "common_issues": [
    "Capacitor failure common at this age",
    "Contactor may show wear",
    "Check refrigerant levels"
  ],
  "replacement_suggestion": {
    "recommended": true,
    "reason": "Unit approaching end of typical lifespan (15-20 years)"
  }
}
```

### Troubleshooting

```
POST /api/v1/ai/troubleshoot
Request: {
  "symptom": "AC running but not cooling, outdoor unit fan spinning",
  "equipment_brand": "Carrier",
  "equipment_model": "24ACC636A003",
  "error_code": null
}
Response: {
  "diagnosis": {
    "likely_causes": [
      {
        "cause": "Low refrigerant charge",
        "probability": "high",
        "check": "Use gauges to check pressures"
      },
      {
        "cause": "Dirty condenser coil",
        "probability": "medium",
        "check": "Visual inspection and cleaning"
      },
      {
        "cause": "Failed compressor",
        "probability": "low",
        "check": "Check compressor amp draw"
      }
    ],
    "diagnostic_steps": [
      "1. Check air filter - replace if dirty",
      "2. Inspect condenser coil for debris",
      "3. Check refrigerant pressures",
      "4. Verify compressor is running and amp draw",
      "5. Check for refrigerant leaks if low"
    ],
    "parts_to_have": [
      "Air filter",
      "Capacitor (35/5 MFD)",
      "Contactor"
    ],
    "safety_notes": [
      "Ensure power is off before checking electrical",
      "Wear safety glasses when checking pressures"
    ]
  }
}

POST /api/v1/ai/lookup-error
Request: {
  "brand": "Carrier",
  "error_code": "E1"
}
Response: {
  "code": "E1",
  "meaning": "Indoor coil temperature sensor fault",
  "causes": [
    "Faulty temperature sensor",
    "Wiring issue",
    "Control board failure"
  ],
  "fix": "Check sensor resistance, replace if out of spec"
}
```

### Follow-Up Calls

```
POST /api/v1/ai/schedule-followup
Request: {
  "job_id": "...",
  "delay_hours": 24
}
Response: {
  "scheduled_for": "2025-01-23T14:30:00Z",
  "followup_id": "..."
}

GET /api/v1/ai/followups
Query: ?status=completed&date=2025-01-22
Response: {
  "items": [
    {
      "id": "...",
      "job_id": "...",
      "customer_name": "John Smith",
      "status": "completed",
      "outcome": "satisfied",
      "rating": 5,
      "review_requested": true,
      "transcript": "..."
    }
  ]
}

POST /api/v1/ai/followup/{id}/trigger
# Manually trigger follow-up call
Response: { "call_initiated": true }
```

### Review Generation

```
POST /api/v1/ai/generate-review
Request: {
  "job_id": "..."
}
Response: {
  "review_text": "Mike from ABC Heating & Air did an excellent job installing our new AC system. He was professional, explained everything clearly, and finished ahead of schedule. The new unit is working perfectly. Highly recommend!",
  "google_review_url": "https://g.page/r/...",
  "rating_suggested": 5
}
```

---

## 6.4 Wireframes

### Photo Analysis (Mobile)
```
┌─────────────────────────────────┐
│ ← Back           Property Photo │
├─────────────────────────────────┤
│                                 │
│  ┌───────────────────────────┐  │
│  │                           │  │
│  │                           │  │
│  │     [CAPTURED PHOTO]      │  │
│  │                           │  │
│  │                           │  │
│  └───────────────────────────┘  │
│                                 │
│  [📷 Retake]    [✓ Analyze]    │
│                                 │
│  ─────────────────────────────  │
│                                 │
│  🤖 AI Analysis                 │
│                                 │
│  ┌───────────────────────────┐  │
│  │ Square Footage            │  │
│  │ ~2,400 sq ft    ●●●○○ 75% │  │
│  │                           │  │
│  │ Sun Exposure              │  │
│  │ Partial         ●●●●○ 85% │  │
│  │                           │  │
│  │ Windows                   │  │
│  │ ~15%            ●●●○○ 70% │  │
│  │                           │  │
│  │ Home Age                  │  │
│  │ 1990s           ●●●○○ 70% │  │
│  │                           │  │
│  │ Notes:                    │  │
│  │ Two-story with mature     │  │
│  │ trees on south side       │  │
│  └───────────────────────────┘  │
│                                 │
│  [ Use These Values ]           │
│                                 │
└─────────────────────────────────┘
```

### Equipment Analysis
```
┌─────────────────────────────────┐
│ ← Back         Equipment Photo  │
├─────────────────────────────────┤
│                                 │
│  ┌───────────────────────────┐  │
│  │                           │  │
│  │   [PHOTO OF AC UNIT]      │  │
│  │                           │  │
│  └───────────────────────────┘  │
│                                 │
│  🤖 AI Identification           │
│                                 │
│  ┌───────────────────────────┐  │
│  │ Brand: Carrier            │  │
│  │ Model: 24ACC636A003       │  │
│  │ Type: Condensing Unit     │  │
│  │ Tonnage: 3 Ton            │  │
│  │ Est. Age: 12-15 years     │  │
│  │ Condition: Fair           │  │
│  └───────────────────────────┘  │
│                                 │
│  ⚠️ Visible Issues              │
│  • Surface rust on cabinet     │
│  • Debris accumulated nearby   │
│                                 │
│  💡 Common Issues at This Age   │
│  • Capacitor failure           │
│  • Contactor wear              │
│  • Low refrigerant             │
│                                 │
│  📋 Recommendation              │
│  ┌───────────────────────────┐  │
│  │ Consider replacement.     │  │
│  │ Unit is 12-15 years old,  │  │
│  │ approaching end of        │  │
│  │ typical 15-20 year life.  │  │
│  └───────────────────────────┘  │
│                                 │
│  [ Add to Job Notes ]           │
│                                 │
└─────────────────────────────────┘
```

### Troubleshooting Assistant
```
┌─────────────────────────────────┐
│ ← Back            Troubleshoot  │
├─────────────────────────────────┤
│                                 │
│  Describe the issue:            │
│  ┌───────────────────────────┐  │
│  │ AC running but not        │  │
│  │ cooling. Outdoor fan is   │  │
│  │ spinning.                 │  │
│  │                      🎤   │  │
│  └───────────────────────────┘  │
│                                 │
│  Equipment (optional):          │
│  [Carrier 24ACC636A003    ▼]    │
│                                 │
│  [ Get Diagnosis ]              │
│                                 │
│  ─────────────────────────────  │
│                                 │
│  🤖 Diagnosis                   │
│                                 │
│  Likely Causes:                 │
│  ┌───────────────────────────┐  │
│  │ 1. Low refrigerant  HIGH  │  │
│  │ 2. Dirty coil       MED   │  │
│  │ 3. Bad compressor   LOW   │  │
│  └───────────────────────────┘  │
│                                 │
│  Diagnostic Steps:              │
│  ☐ 1. Check air filter          │
│  ☐ 2. Inspect condenser coil    │
│  ☐ 3. Check refrigerant press.  │
│  ☐ 4. Verify compressor amps    │
│  ☐ 5. Check for leaks           │
│                                 │
│  Parts to Have Ready:           │
│  • Air filter                   │
│  • Capacitor (35/5 MFD)         │
│  • Contactor                    │
│                                 │
│  ⚠️ Safety: Power off before    │
│  checking electrical            │
│                                 │
└─────────────────────────────────┘
```

### Follow-Up Results
```
┌────────────────────────────────────────────────────────────────────────┐
│  Follow-Up Calls                                       Jan 22, 2025   │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  Today's Completed: 5    Satisfied: 4    Issues: 1    Reviews: 3      │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ ✅ John Smith                                        ⭐⭐⭐⭐⭐│   │
│  │ Jan 21 Install • Mike Johnson                                  │   │
│  │                                                                │   │
│  │ "Everything working great, very happy with the install"        │   │
│  │                                                                │   │
│  │ ✓ Review requested and posted                                  │   │
│  │                                                                │   │
│  │ [View Transcript]                                              │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ ⚠️ Bob Wilson                                         ⭐⭐⭐   │   │
│  │ Jan 21 Service • Sarah Kim                                     │   │
│  │                                                                │   │
│  │ "Unit is working but making a clicking noise"                  │   │
│  │                                                                │   │
│  │ 🔔 Issue flagged - Callback scheduled                          │   │
│  │                                                                │   │
│  │ [View Transcript] [View Callback]                              │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ ✅ Mary Jones                                        ⭐⭐⭐⭐⭐│   │
│  │ Jan 21 Install • Tom Baker                                     │   │
│  │                                                                │   │
│  │ "Perfect! Tom was professional and thorough"                   │   │
│  │                                                                │   │
│  │ ✓ Review requested - pending                                   │   │
│  │                                                                │   │
│  │ [View Transcript]                                              │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Review Request SMS
```
┌─────────────────────────────────┐
│                                 │
│  From: ABC Heating & Air        │
│                                 │
│  ┌───────────────────────────┐  │
│  │ Thank you for choosing    │  │
│  │ ABC Heating! We're glad   │  │
│  │ you're happy with your    │  │
│  │ new AC system. Would you  │  │
│  │ mind leaving us a quick   │  │
│  │ Google review? Here's a   │  │
│  │ suggested review you can  │  │
│  │ copy:                     │  │
│  │                           │  │
│  │ "Mike from ABC Heating    │  │
│  │ did an excellent job      │  │
│  │ installing our new AC.    │  │
│  │ Professional, on-time,    │  │
│  │ and the unit works great. │  │
│  │ Highly recommend!"        │  │
│  │                           │  │
│  │ Leave review:             │  │
│  │ g.page/r/abc-heating      │  │
│  └───────────────────────────┘  │
│                                 │
└─────────────────────────────────┘
```

---

## 6.5 Implementation Checklist

### Sprint 14-15 (Week 25-28): Photo AI

#### Property Analysis
- [ ] Create image upload endpoint
- [ ] Integrate Claude Vision API
- [ ] Build analysis prompt for property photos
- [ ] Parse structured response
- [ ] Return confidence scores
- [ ] Mobile: Camera integration
- [ ] Mobile: Analysis results display
- [ ] Auto-populate Duculator form

#### Equipment Analysis
- [ ] Create equipment analysis prompt
- [ ] Train on common HVAC brands/models
- [ ] Issue detection logic
- [ ] Age estimation heuristics
- [ ] Mobile: Equipment photo flow
- [ ] Link to job for reference

### Sprint 16 (Week 29-30): Troubleshooting & Follow-Ups

#### Troubleshooting Assistant
- [ ] Build troubleshooting prompt
- [ ] Error code database
- [ ] Diagnostic step generator
- [ ] Parts suggestion logic
- [ ] Mobile: Troubleshoot screen
- [ ] Voice input option
- [ ] Checklist tracking

#### Follow-Up System
- [ ] Schedule follow-up on job complete
- [ ] Background job runner
- [ ] AI follow-up call script
- [ ] Outcome recording
- [ ] Issue escalation flow
- [ ] Dashboard widget

#### Review Generation
- [ ] Review text generator
- [ ] Google Business link builder
- [ ] SMS template for review request
- [ ] Tracking (requested, posted)

---

## 6.6 Claude Code Prompts

### Prompt 1: Property Photo Analysis
```
Implement property photo analysis with Claude Vision:

API Endpoint:
- Accept image upload (JPEG, PNG)
- Send to Claude Vision with prompt
- Parse structured response
- Return with confidence scores

Analysis Prompt:
"Analyze this exterior home photo for HVAC sizing estimation:
1. Estimate square footage based on visible structure
2. Assess sun exposure (shady/partial/full) from trees and orientation
3. Estimate window coverage as percentage
4. Identify roof type and home age/era
5. Note any visible HVAC equipment

Return JSON with estimates and confidence (0-1) for each."

Response Processing:
- Validate confidence thresholds
- Map to Duculator input fields
- Flag low-confidence items for manual review
```

### Prompt 2: Equipment Recognition
```
Build equipment photo analysis:

Claude Vision Prompt:
"Identify this HVAC equipment:
1. Brand (from nameplate, logo, or cabinet style)
2. Model number if visible
3. Equipment type (condenser, air handler, furnace, etc.)
4. Estimated tonnage from physical size
5. Estimated age from style and condition
6. Visible issues or damage
7. Overall condition rating

Also provide:
- Common failure points for this equipment age
- Replacement recommendation with reasoning"

Database Enhancement:
- Store equipment profiles by brand/model
- Link common issues and parts
- Track equipment across customer jobs
```

### Prompt 3: Troubleshooting AI
```
Create HVAC troubleshooting assistant:

Input Processing:
- Accept text or voice (transcribed) symptom description
- Optional: equipment brand/model, error code

Claude Prompt:
"As an expert HVAC technician, diagnose this issue:
Symptom: {symptom}
Equipment: {brand} {model}
Error Code: {code}

Provide:
1. Ranked list of likely causes with probability
2. Step-by-step diagnostic procedure
3. Parts that may be needed
4. Safety warnings
5. Estimated repair time"

Error Code Lookup:
- Build database of common error codes by manufacturer
- Return meaning, causes, and fixes
```

### Prompt 4: Automated Follow-Up
```
Implement AI follow-up call system:

Scheduling:
- Trigger: Job marked complete
- Delay: 24 hours (configurable)
- Check: Customer has phone, opted-in

Call Script:
"Hi, this is Clara from {company}. I'm calling to check on your recent {job_type}. How is everything working?

[If positive]:
"That's wonderful to hear! Would you mind leaving us a quick Google review? I can text you a link with a suggested review based on your service. It would really help us out!"

[If issues]:
"I'm sorry to hear that. Let me make a note and have someone call you back today to get that resolved. Is this number the best way to reach you?"

Post-Call:
- Log outcome and rating
- If happy: Send review request SMS
- If issues: Create callback task
- Store transcript
```

---

## 6.7 Files to Create

```
backend/
├── app/
│   ├── api/v1/
│   │   ├── ai_analysis.py      # NEW
│   │   ├── troubleshoot.py     # NEW
│   │   └── followup.py         # NEW
│   ├── services/
│   │   ├── vision_service.py   # NEW
│   │   ├── troubleshoot_service.py  # NEW
│   │   └── followup_service.py # NEW
│   ├── data/
│   │   └── error_codes.json    # NEW
│   └── tasks/
│       └── followup_tasks.py   # NEW

frontend/
├── src/
│   ├── components/
│   │   └── ai/
│   │       ├── FollowUpDashboard.tsx  # NEW
│   │       └── ReviewRequest.tsx      # NEW
│   └── pages/
│       └── FollowUps.tsx              # NEW

mobile/
├── app/
│   ├── photo-analyze.tsx       # NEW
│   ├── equipment-scan.tsx      # NEW
│   └── troubleshoot.tsx        # NEW
├── components/
│   ├── PropertyAnalysis.tsx    # NEW
│   ├── EquipmentAnalysis.tsx   # NEW
│   └── TroubleshootChat.tsx    # NEW
```

---

**End of Phase 6 Documentation**

Proceed to `PHASE7_PROCUREMENT.md` after completing Phase 6.
