# Phase 1: Foundation

**Duration:** 6 weeks
**Goal:** Complete Duculator+ MVP with job creation

---

## 1.1 Prerequisites

- GitHub repo created
- MongoDB Atlas account
- Railway account
- Vercel account
- Mapbox account (for geocoding)

---

## 1.2 Goals

By end of Phase 1, contractors can:
- Register company and login
- Enter property details and get load calculation
- View Good/Better/Best equipment options
- See complete job pricing with margins
- Create and manage customers
- Create jobs from estimates
- Generate PDF quotes

---

## 1.3 Database Models

### User
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "email": str,
  "password_hash": str,
  "first_name": str,
  "last_name": str,
  "role": "owner" | "admin" | "dispatcher" | "tech",
  "is_active": bool,
  "created_at": datetime,
  "updated_at": datetime
}
```

### Company
```python
{
  "_id": ObjectId,
  "name": str,
  "phone": str,
  "email": str,
  "address": str,
  "city": str,
  "state": str,
  "zip_code": str,
  "logo_url": str | None,
  "settings": {
    "labor_rate_install": float,      # Default: 85.00
    "labor_rate_helper": float,       # Default: 45.00
    "overhead_percentage": float,     # Default: 0.15
    "profit_percentage": float,       # Default: 0.20
    "default_job_duration": float,    # Default: 6.0 hours
  },
  "subscription": {
    "tier": "starter" | "pro" | "business" | "enterprise",
    "tech_limit": int,
    "expires_at": datetime | None
  },
  "created_at": datetime,
  "updated_at": datetime
}
```

### Customer
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "first_name": str,
  "last_name": str,
  "phone": str,
  "email": str | None,
  "address": str,
  "city": str,
  "state": str,
  "zip_code": str,
  "location": {
    "type": "Point",
    "coordinates": [lng, lat]
  },
  "sms_opt_in": bool,
  "notes": str | None,
  "job_count": int,
  "total_revenue": float,
  "created_at": datetime,
  "updated_at": datetime
}
```

### Equipment
```python
{
  "_id": ObjectId,
  "brand": str,                       # "Trane", "American Standard", "Amana"
  "model": str,
  "tier": "good" | "better" | "best",
  "tons": float,                      # 1.5, 2, 2.5, 3, 3.5, 4, 5
  "seer": float,
  "cfm": int,
  "cost": float,                      # Contractor cost
  "msrp": float,                      # List price
  "warranty": {
    "parts_years": int,
    "labor_years": int,
    "compressor_years": int,
    "description": str
  },
  "distributor": str,
  "in_stock": bool,
  "lead_time_days": int,
  "updated_at": datetime
}
```

### Job
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "customer_id": ObjectId,
  "job_number": str,                  # Auto-generated: "JOB-2025-0001"
  "job_type": "install" | "service" | "maintenance" | "estimate",
  "status": "draft" | "quoted" | "approved" | "scheduled" | "in_progress" | "complete" | "invoiced" | "paid" | "cancelled",
  
  "property": {
    "zip_code": str,
    "sqft": int,
    "sun_exposure": "shady" | "partial" | "full",
    "occupancy": int,
    "ceiling_height": float,
    "insulation": "poor" | "average" | "good",
    "window_percentage": int
  },
  
  "load_calculation": {
    "btu": int,
    "tons": float,
    "cfm": int
  },
  
  "duct_sizing": {
    "supply_outlets": int,
    "return_size": str,
    "trunk_size": str,
    "branch_size": str
  },
  
  "climate": {
    "region": str,
    "humidity": float,
    "design_temp": int
  },
  
  "equipment_id": ObjectId | None,
  "selected_tier": "good" | "better" | "best" | None,
  
  "line_items": [
    {
      "id": str,
      "description": str,
      "category": "equipment" | "materials" | "labor" | "other",
      "quantity": float,
      "unit_price": float,
      "total": float
    }
  ],
  
  "pricing": {
    "equipment": float,
    "materials": float,
    "labor": float,
    "subtotal": float,
    "overhead": float,
    "profit": float,
    "total": float,
    "margin_percentage": float
  },
  
  "schedule": {
    "scheduled_date": datetime | None,
    "scheduled_time": str | None,
    "tech_id": ObjectId | None,
    "estimated_hours": float
  },
  
  "completion": {
    "started_at": datetime | None,
    "completed_at": datetime | None,
    "tech_notes": str | None,
    "photos": [str],
    "signature_url": str | None
  },
  
  "created_at": datetime,
  "updated_at": datetime
}
```

---

## 1.4 API Endpoints

### Authentication

```
POST /api/v1/auth/register
Request:
{
  "company_name": "ABC Heating & Air",
  "email": "owner@abchvac.com",
  "password": "securepass123",
  "first_name": "John",
  "last_name": "Smith",
  "phone": "555-123-4567"
}
Response:
{
  "access_token": "eyJ...",
  "refresh_token": "eyJ...",
  "token_type": "bearer",
  "user": { ... },
  "company": { ... }
}

POST /api/v1/auth/login
Request:
{
  "email": "owner@abchvac.com",
  "password": "securepass123"
}
Response:
{
  "access_token": "eyJ...",
  "refresh_token": "eyJ...",
  "token_type": "bearer",
  "user": { ... }
}

POST /api/v1/auth/refresh
Request:
{
  "refresh_token": "eyJ..."
}
Response:
{
  "access_token": "eyJ...",
  "token_type": "bearer"
}

GET /api/v1/auth/me
Headers: Authorization: Bearer {token}
Response:
{
  "id": "...",
  "email": "...",
  "first_name": "...",
  "last_name": "...",
  "role": "owner",
  "company": { ... }
}
```

### Company

```
GET /api/v1/company
Response: Company object

PUT /api/v1/company
Request: Partial company update
Response: Updated company

PUT /api/v1/company/settings
Request:
{
  "labor_rate_install": 90.00,
  "labor_rate_helper": 48.00,
  "overhead_percentage": 0.15,
  "profit_percentage": 0.22
}
Response: Updated settings
```

### Calculate

```
POST /api/v1/calculate/load
Request:
{
  "zip_code": "36830",
  "sqft": 2400,
  "sun_exposure": "partial",
  "occupancy": 4,
  "ceiling_height": 9,
  "insulation": "average",
  "window_percentage": 15
}
Response:
{
  "load": {
    "btu": 42000,
    "tons": 3.5,
    "cfm": 1400
  },
  "ducts": {
    "supply_outlets": 14,
    "return_size": "20x25",
    "trunk_size": "12x20",
    "branch_size": "7\""
  },
  "climate": {
    "region": "Central Alabama",
    "humidity": 68,
    "design_temp": 94
  }
}

POST /api/v1/calculate/equipment
Request:
{
  "tons": 3.5
}
Response:
{
  "good": { brand, model, seer, warranty, price, ... },
  "better": { ... },
  "best": { ... }
}

POST /api/v1/calculate/pricing
Request:
{
  "equipment_id": "...",
  "tons": 3.5,
  "duct_outlets": 14
}
Response:
{
  "line_items": [ ... ],
  "pricing": {
    "equipment": 5400,
    "materials": 1850,
    "labor": 1240,
    "subtotal": 8490,
    "overhead": 1274,
    "profit": 1698,
    "total": 11462,
    "margin_percentage": 17.4
  }
}
```

### Customers

```
GET /api/v1/customers?search=smith&page=1&limit=20
Response:
{
  "items": [ ... ],
  "total": 45,
  "page": 1,
  "pages": 3
}

GET /api/v1/customers/{id}
Response: Customer object with job history

POST /api/v1/customers
Request: Customer data
Response: Created customer

PUT /api/v1/customers/{id}
Request: Partial customer update
Response: Updated customer

DELETE /api/v1/customers/{id}
Response: { "deleted": true }
```

### Jobs

```
GET /api/v1/jobs?status=quoted&page=1&limit=20
Response:
{
  "items": [ ... ],
  "total": 123,
  "page": 1,
  "pages": 7
}

GET /api/v1/jobs/{id}
Response: Full job object

POST /api/v1/jobs
Request:
{
  "customer_id": "...",
  "job_type": "install",
  "property": { ... },
  "load_calculation": { ... },
  "duct_sizing": { ... },
  "climate": { ... },
  "equipment_id": "...",
  "selected_tier": "better",
  "line_items": [ ... ],
  "pricing": { ... }
}
Response: Created job

PUT /api/v1/jobs/{id}
Request: Partial job update
Response: Updated job

PATCH /api/v1/jobs/{id}/status
Request:
{
  "status": "approved"
}
Response: Updated job

GET /api/v1/jobs/{id}/quote.pdf
Response: PDF file

POST /api/v1/jobs/{id}/send-quote
Request:
{
  "email": "customer@email.com"
}
Response: { "sent": true }
```

### Equipment

```
GET /api/v1/equipment?brand=Trane&tons=3.5
Response: [ ... equipment list ... ]

GET /api/v1/equipment/{id}
Response: Equipment object

POST /api/v1/equipment (admin only)
Request: Equipment data
Response: Created equipment

PUT /api/v1/equipment/{id} (admin only)
Request: Partial update
Response: Updated equipment
```

---

## 1.5 Wireframes

### Login Page
```
┌─────────────────────────────────────────────────────────┐
│                                                         │
│                    ┌──────────────┐                     │
│                    │      W       │                     │
│                    │   TheWorx    │                     │
│                    └──────────────┘                     │
│                                                         │
│              ┌─────────────────────────┐                │
│              │ Email                   │                │
│              └─────────────────────────┘                │
│              ┌─────────────────────────┐                │
│              │ Password                │                │
│              └─────────────────────────┘                │
│                                                         │
│              ┌─────────────────────────┐                │
│              │        Sign In          │                │
│              └─────────────────────────┘                │
│                                                         │
│              Don't have an account? Register            │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Main Layout
```
┌────────────────────────────────────────────────────────────────────────┐
│ ┌──────┐                                              ABC Heating  [▼] │
│ │  W   │  Dashboard  Jobs  Customers  Dispatch  Equipment  Settings    │
│ └──────┘                                                               │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│   [Page Content Area]                                                  │
│                                                                        │
│                                                                        │
│                                                                        │
│                                                                        │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Dashboard
```
┌────────────────────────────────────────────────────────────────────────┐
│  Dashboard                                            [+ New Estimate] │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐   │
│  │   Today     │  │   This Week │  │   Pipeline  │  │   Revenue   │   │
│  │     3       │  │     12      │  │    $147K    │  │   $23.4K    │   │
│  │    jobs     │  │    jobs     │  │   28 jobs   │  │   this week │   │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘   │
│                                                                        │
│  Upcoming Jobs                                           View All →    │
│  ┌──────────────────────────────────────────────────────────────────┐ │
│  │ ● 9:00 AM   John Smith - 123 Main St        Install 3.5T  $14.2K │ │
│  │ ● 1:00 PM   Mary Jones - 456 Oak Ave        Service       $350   │ │
│  │ ○ 3:00 PM   Bob Wilson - 789 Pine Rd        Install 4T    $16.8K │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│                                                                        │
│  Recent Quotes                                           View All →    │
│  ┌──────────────────────────────────────────────────────────────────┐ │
│  │ JOB-2025-0042  Lisa Chen      $12,450   Quoted   Jan 20         │ │
│  │ JOB-2025-0041  Tom Brown      $18,200   Quoted   Jan 19         │ │
│  │ JOB-2025-0040  Sara Davis     $9,800    Approved Jan 18         │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Duculator - Step 1: Property Input
```
┌────────────────────────────────────────────────────────────────────────┐
│  New Estimate                                                          │
│                                                                        │
│  ○ Input → ○ Size → ○ Equipment → ○ Price → ○ Customer → ○ Review     │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  Property Details                                                      │
│                                                                        │
│  ┌─────────────────────┐    ┌─────────────────────┐                   │
│  │ ZIP Code            │    │ Square Footage      │                   │
│  │ [36830         ]    │    │ [2400          ]    │                   │
│  │ 📍 Central Alabama  │    │                     │                   │
│  │    68% humidity     │    │                     │                   │
│  └─────────────────────┘    └─────────────────────┘                   │
│                                                                        │
│  Sun Exposure                                                          │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐                                │
│  │   🌳    │  │   ⛅    │  │   ☀️    │                                │
│  │  Shady  │  │ Partial │  │  Full   │                                │
│  └─────────┘  └────●────┘  └─────────┘                                │
│                                                                        │
│  ┌─────────────────────┐    ┌─────────────────────┐                   │
│  │ Occupancy           │    │ Ceiling Height (ft) │                   │
│  │ [ − ]  4  [ + ]     │    │ [9              ]   │                   │
│  └─────────────────────┘    └─────────────────────┘                   │
│                                                                        │
│  Insulation Quality                                                    │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐                                │
│  │  Poor   │  │ Average │  │  Good   │                                │
│  └─────────┘  └────●────┘  └─────────┘                                │
│                                                                        │
│  Window Coverage: 15%                                                  │
│  ├────────●────────────────────────────────┤                          │
│  5%                                      40%                           │
│                                                                        │
│                                    ┌──────────────────────┐            │
│                                    │   Calculate Load  →  │            │
│                                    └──────────────────────┘            │
└────────────────────────────────────────────────────────────────────────┘
```

### Duculator - Step 2: Load Results
```
┌────────────────────────────────────────────────────────────────────────┐
│  New Estimate                                                          │
│                                                                        │
│  ● Input → ○ Size → ○ Equipment → ○ Price → ○ Customer → ○ Review     │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  Load Calculation Results                   [← Edit Inputs]            │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │                                                                │   │
│  │   ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐     │   │
│  │   │  42,000  │  │   3.5    │  │  1,400   │  │    14    │     │   │
│  │   │  BTU/hr  │  │   Tons   │  │   CFM    │  │ Outlets  │     │   │
│  │   └──────────┘  └──────────┘  └──────────┘  └──────────┘     │   │
│  │                                                                │   │
│  │   ─────────────────────────────────────────────────────────   │   │
│  │                                                                │   │
│  │   Ductwork Sizing                                             │   │
│  │   Return: 20x25    Trunk: 12x20    Branch: 7"                 │   │
│  │                                                                │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  Climate Data: Central Alabama                                         │
│  Design Temp: 94°F  |  Humidity: 68%  |  Cooling Days: 2000           │
│                                                                        │
│                                    ┌──────────────────────┐            │
│                                    │  Select Equipment →  │            │
│                                    └──────────────────────┘            │
└────────────────────────────────────────────────────────────────────────┘
```

### Duculator - Step 3: Equipment Selection
```
┌────────────────────────────────────────────────────────────────────────┐
│  New Estimate                                                          │
│                                                                        │
│  ● Input → ● Size → ○ Equipment → ○ Price → ○ Customer → ○ Review     │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  Select Equipment - 3.5 Ton                         [← Back to Sizing] │
│                                                                        │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐        │
│  │      GOOD       │  │     BETTER      │  │      BEST       │        │
│  │                 │  │  ┌───────────┐  │  │                 │        │
│  │     Amana       │  │  │BEST VALUE │  │  │     Trane       │        │
│  │     ASX14       │  │  └───────────┘  │  │     XR17        │        │
│  │                 │  │                 │  │                 │        │
│  │    14 SEER      │  │  Am. Standard   │  │    17 SEER      │        │
│  │                 │  │   Silver 15     │  │                 │        │
│  │ ───────────────│  │                 │  │ ─────────────── │        │
│  │                 │  │    15 SEER      │  │                 │        │
│  │ 10yr Parts      │  │                 │  │ 12yr Parts      │        │
│  │                 │  │ ─────────────── │  │ 12yr Labor      │        │
│  │                 │  │                 │  │ 12yr Compressor │        │
│  │ ═══════════════│  │ 12yr Parts      │  │                 │        │
│  │                 │  │ 12yr Labor      │  │ ═══════════════ │        │
│  │  Equip: $4,200  │  │                 │  │                 │        │
│  │                 │  │ ═══════════════ │  │  Equip: $7,200  │        │
│  │                 │  │                 │  │                 │        │
│  │   [ Select ]    │  │  Equip: $5,400  │  │   [ Select ]    │        │
│  │                 │  │                 │  │                 │        │
│  └─────────────────┘  │   [ Select ]    │  └─────────────────┘        │
│                       │                 │                              │
│                       └─────────────────┘                              │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Duculator - Step 4: Pricing
```
┌────────────────────────────────────────────────────────────────────────┐
│  New Estimate                                                          │
│                                                                        │
│  ● Input → ● Size → ● Equipment → ○ Price → ○ Customer → ○ Review     │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  Job Pricing - American Standard Silver 15          [← Change Equip]   │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │                                                                │   │
│  │  Equipment                                           $5,400    │   │
│  │    American Standard Silver 15 - 3.5 Ton                      │   │
│  │  ──────────────────────────────────────────────────────────── │   │
│  │  Materials                                           $1,850    │   │
│  │    Line set (30ft)                         $250               │   │
│  │    Refrigerant (3.5 × $45)                 $158               │   │
│  │    Electrical                              $250               │   │
│  │    Thermostat                              $85                │   │
│  │    Concrete pad                            $65                │   │
│  │    Ductwork (14 outlets × $120)            $1,680             │   │
│  │    Misc supplies                           $150               │   │
│  │  ──────────────────────────────────────────────────────────── │   │
│  │  Labor                                               $1,240    │   │
│  │    Install tech (11.25 hrs × $85)          $956               │   │
│  │    Helper (11.25 hrs × $45)                $506               │   │
│  │  ════════════════════════════════════════════════════════════ │   │
│  │  Subtotal                                            $8,490    │   │
│  │  Overhead (15%)                                      $1,274    │   │
│  │  Profit (20%)                                        $1,698    │   │
│  │  ════════════════════════════════════════════════════════════ │   │
│  │                                                                │   │
│  │  TOTAL                                              $11,462    │   │
│  │                                          Margin: 17.4% ✓      │   │
│  │                                                                │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│                                    ┌──────────────────────┐            │
│                                    │  Add Customer     →  │            │
│                                    └──────────────────────┘            │
└────────────────────────────────────────────────────────────────────────┘
```

### Duculator - Step 5: Customer
```
┌────────────────────────────────────────────────────────────────────────┐
│  New Estimate                                                          │
│                                                                        │
│  ● Input → ● Size → ● Equipment → ● Price → ○ Customer → ○ Review     │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  Customer Information                                                  │
│                                                                        │
│  Search existing: [                              ] 🔍                  │
│                                                                        │
│  ── OR CREATE NEW ──────────────────────────────────────────────────  │
│                                                                        │
│  ┌─────────────────────┐    ┌─────────────────────┐                   │
│  │ First Name          │    │ Last Name           │                   │
│  │ [John            ]  │    │ [Smith           ]  │                   │
│  └─────────────────────┘    └─────────────────────┘                   │
│                                                                        │
│  ┌─────────────────────┐    ┌─────────────────────┐                   │
│  │ Phone               │    │ Email (optional)    │                   │
│  │ [(555) 123-4567 ]   │    │ [john@email.com  ]  │                   │
│  └─────────────────────┘    └─────────────────────┘                   │
│                                                                        │
│  ┌──────────────────────────────────────────────────┐                 │
│  │ Address                                          │                 │
│  │ [123 Main Street                              ]  │                 │
│  └──────────────────────────────────────────────────┘                 │
│                                                                        │
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────┐               │
│  │ City            │  │ State           │  │ ZIP      │               │
│  │ [Auburn      ]  │  │ [AL          ]  │  │ [36830]  │               │
│  └─────────────────┘  └─────────────────┘  └──────────┘               │
│                                                                        │
│  ☑ Customer agrees to receive SMS updates                             │
│                                                                        │
│                                    ┌──────────────────────┐            │
│                                    │   Review Estimate →  │            │
│                                    └──────────────────────┘            │
└────────────────────────────────────────────────────────────────────────┘
```

### Duculator - Step 6: Review & Create
```
┌────────────────────────────────────────────────────────────────────────┐
│  New Estimate                                                          │
│                                                                        │
│  ● Input → ● Size → ● Equipment → ● Price → ● Customer → ○ Review     │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  Review Estimate                                                       │
│                                                                        │
│  ┌──────────────────────────────┐  ┌──────────────────────────────┐   │
│  │ Customer                     │  │ Property                     │   │
│  │ John Smith                   │  │ 2,400 sq ft                  │   │
│  │ (555) 123-4567               │  │ Partial sun, Avg insulation  │   │
│  │ 123 Main Street              │  │ 4 occupants, 9ft ceilings    │   │
│  │ Auburn, AL 36830             │  │                              │   │
│  └──────────────────────────────┘  └──────────────────────────────┘   │
│                                                                        │
│  ┌──────────────────────────────┐  ┌──────────────────────────────┐   │
│  │ System                       │  │ Ductwork                     │   │
│  │ 3.5 Ton / 42,000 BTU        │  │ 14 supply outlets            │   │
│  │ American Standard Silver 15  │  │ Return: 20x25                │   │
│  │ 15 SEER                      │  │ Trunk: 12x20                 │   │
│  │ 12yr Parts & Labor           │  │ Branch: 7"                   │   │
│  └──────────────────────────────┘  └──────────────────────────────┘   │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │                                                                │   │
│  │  Equipment        $5,400      Labor           $1,240          │   │
│  │  Materials        $1,850      Overhead        $1,274          │   │
│  │                               Profit          $1,698          │   │
│  │  ──────────────────────────────────────────────────────────   │   │
│  │                               TOTAL          $11,462          │   │
│  │                                                                │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  ┌─────────────────┐  ┌───────────────────┐  ┌───────────────────┐   │
│  │  Save as Draft  │  │  Create & Email   │  │   Create Quote    │   │
│  └─────────────────┘  └───────────────────┘  └───────────────────┘   │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Jobs List
```
┌────────────────────────────────────────────────────────────────────────┐
│  Jobs                                                 [+ New Estimate] │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  [All] [Draft] [Quoted] [Approved] [Scheduled] [Complete]    🔍 Search │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ JOB-2025-0045                                                  │   │
│  │ John Smith • 123 Main St, Auburn             ┌─────────────┐  │   │
│  │ 3.5 Ton Install - Am Std Silver 15           │   QUOTED    │  │   │
│  │                                              └─────────────┘  │   │
│  │ $11,462                                      Created: Jan 21  │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ JOB-2025-0044                                                  │   │
│  │ Mary Jones • 456 Oak Ave, Opelika            ┌─────────────┐  │   │
│  │ 4 Ton Install - Trane XR17                   │  APPROVED   │  │   │
│  │                                              └─────────────┘  │   │
│  │ $16,842                                      Created: Jan 20  │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ JOB-2025-0043                                                  │   │
│  │ Bob Wilson • 789 Pine Rd, Auburn             ┌─────────────┐  │   │
│  │ Service Call                                 │  COMPLETE   │  │   │
│  │                                              └─────────────┘  │   │
│  │ $285                                         Created: Jan 19  │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  ← Previous                                              Next →        │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Job Detail
```
┌────────────────────────────────────────────────────────────────────────┐
│  ← Back to Jobs              JOB-2025-0045                             │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ┌─────────────────────────────────────────────────────────────────┐  │
│  │  John Smith                                    ┌─────────────┐  │  │
│  │  (555) 123-4567 • john@email.com               │   QUOTED    │  │  │
│  │  123 Main Street, Auburn, AL 36830             └─────────────┘  │  │
│  │                                                                 │  │
│  │  [📞 Call]  [💬 Text]  [📧 Email]  [📍 Directions]              │  │
│  └─────────────────────────────────────────────────────────────────┘  │
│                                                                        │
│  ┌────────────────────────┐  ┌────────────────────────────────────┐   │
│  │ System                 │  │ Actions                            │   │
│  │                        │  │                                    │   │
│  │ 3.5 Ton / 42,000 BTU  │  │  [Mark Approved]                   │   │
│  │ American Standard      │  │                                    │   │
│  │ Silver 15 • 15 SEER    │  │  [Schedule Job]                    │   │
│  │                        │  │                                    │   │
│  │ 12yr Parts & Labor     │  │  [Send Quote]                      │   │
│  │                        │  │                                    │   │
│  │ 14 outlets, 1400 CFM   │  │  [Download PDF]                    │   │
│  │                        │  │                                    │   │
│  └────────────────────────┘  │  [Edit Job]                        │   │
│                              │                                    │   │
│  ┌────────────────────────┐  │  [Cancel Job]                      │   │
│  │ Pricing                │  │                                    │   │
│  │                        │  └────────────────────────────────────┘   │
│  │ Equipment    $5,400    │                                          │
│  │ Materials    $1,850    │  Activity                                │
│  │ Labor        $1,240    │  ──────────────────────────────────────  │
│  │ Overhead     $1,274    │  Jan 21 10:32 - Quote created            │
│  │ Profit       $1,698    │  Jan 21 10:30 - Customer created         │
│  │ ─────────────────────  │  Jan 21 10:15 - Estimate started         │
│  │ Total       $11,462    │                                          │
│  │ Margin        17.4%    │                                          │
│  └────────────────────────┘                                          │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Customers List
```
┌────────────────────────────────────────────────────────────────────────┐
│  Customers                                              [+ New Customer]│
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  🔍 [Search by name, phone, or address...                           ]  │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ John Smith                                                     │   │
│  │ (555) 123-4567 • john@email.com                               │   │
│  │ 123 Main Street, Auburn, AL 36830                             │   │
│  │                                                                │   │
│  │ 3 jobs • $34,520 lifetime                    Last: Jan 21     │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ Mary Jones                                                     │   │
│  │ (555) 987-6543 • mary.jones@email.com                         │   │
│  │ 456 Oak Avenue, Opelika, AL 36801                             │   │
│  │                                                                │   │
│  │ 1 job • $16,842 lifetime                     Last: Jan 20     │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  Showing 1-20 of 156 customers                                         │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Settings - Pricing
```
┌────────────────────────────────────────────────────────────────────────┐
│  Settings                                                              │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  [Company] [Pricing] [SMS Templates] [Users] [Integrations]            │
│                                                                        │
│  Labor Rates                                                           │
│  ┌─────────────────────────────────────────────────────────────────┐  │
│  │                                                                 │  │
│  │  Install Technician Rate        $ [85.00        ] /hour        │  │
│  │                                                                 │  │
│  │  Helper Rate                    $ [45.00        ] /hour        │  │
│  │                                                                 │  │
│  └─────────────────────────────────────────────────────────────────┘  │
│                                                                        │
│  Margins                                                               │
│  ┌─────────────────────────────────────────────────────────────────┐  │
│  │                                                                 │  │
│  │  Overhead Percentage              [15           ] %            │  │
│  │                                                                 │  │
│  │  Profit Percentage                [20           ] %            │  │
│  │                                                                 │  │
│  └─────────────────────────────────────────────────────────────────┘  │
│                                                                        │
│  Job Defaults                                                          │
│  ┌─────────────────────────────────────────────────────────────────┐  │
│  │                                                                 │  │
│  │  Default Job Duration             [6.0          ] hours        │  │
│  │                                                                 │  │
│  └─────────────────────────────────────────────────────────────────┘  │
│                                                                        │
│                                           ┌─────────────────────┐     │
│                                           │    Save Changes     │     │
│                                           └─────────────────────┘     │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 1.6 Implementation Checklist

### Sprint 1 (Week 1-2): Setup & Duculator Core

#### Project Setup
- [ ] Create GitHub repository `theworx`
- [ ] Initialize monorepo structure (see README)
- [ ] Create `docker-compose.yml` for local dev
- [ ] Create `.env.example` with all variables
- [ ] Setup GitHub Actions for CI

#### Backend Setup
- [ ] Initialize FastAPI project with Poetry or pip
- [ ] Create `requirements.txt`:
  ```
  fastapi==0.109.0
  uvicorn[standard]==0.27.0
  motor==3.3.2
  pydantic==2.5.3
  pydantic-settings==2.1.0
  python-jose[cryptography]==3.3.0
  passlib[bcrypt]==1.7.4
  python-multipart==0.0.6
  httpx==0.26.0
  weasyprint==60.2
  jinja2==3.1.3
  ```
- [ ] Create `app/config.py` with Settings class
- [ ] Create `app/database.py` with MongoDB connection
- [ ] Create `app/main.py` with FastAPI app
- [ ] Test local server starts

#### Authentication
- [ ] Create `app/models/user.py`
- [ ] Create `app/models/company.py`
- [ ] Create `app/core/security.py` (JWT, password hashing)
- [ ] Create `app/services/auth_service.py`
- [ ] Create `app/api/v1/auth.py` with:
  - [ ] POST `/register`
  - [ ] POST `/login`
  - [ ] POST `/refresh`
  - [ ] GET `/me`
- [ ] Create `app/api/deps.py` with `get_current_user`
- [ ] Write tests for auth endpoints

#### Frontend Setup
- [ ] Initialize Vite + React + TypeScript
- [ ] Install and configure Tailwind CSS
- [ ] Create `src/api/client.ts` (Axios with interceptors)
- [ ] Create `src/context/AuthContext.tsx`
- [ ] Create `src/hooks/useAuth.ts`
- [ ] Create Login page
- [ ] Create Register page
- [ ] Create protected route wrapper
- [ ] Create basic Layout component

#### Duculator API
- [ ] Create `app/data/climate_zones.json`
- [ ] Create `app/services/load_calculator.py`:
  - [ ] `calculate_load()` function
  - [ ] `calculate_duct_sizing()` function
  - [ ] `get_climate_data()` function
- [ ] Create `app/api/v1/calculate.py`:
  - [ ] POST `/calculate/load`
- [ ] Write unit tests for calculations

#### Duculator Frontend
- [ ] Create `src/components/duculator/PropertyForm.tsx`
- [ ] Create `src/components/duculator/LoadResults.tsx`
- [ ] Create `src/components/duculator/DuctSizing.tsx`
- [ ] Create `src/pages/Duculator.tsx` with step wizard
- [ ] Connect to API
- [ ] Test full flow

### Sprint 2 (Week 3-4): Equipment & Pricing

#### Equipment Database
- [ ] Create `app/models/equipment.py`
- [ ] Create `app/data/equipment_seed.json`
- [ ] Create seed script
- [ ] Create `app/api/v1/equipment.py`:
  - [ ] GET `/equipment`
  - [ ] GET `/equipment/{id}`
  - [ ] POST `/equipment` (admin)
  - [ ] PUT `/equipment/{id}` (admin)

#### Equipment Matcher
- [ ] Create `app/services/equipment_matcher.py`:
  - [ ] `match_equipment_by_tons()` function
  - [ ] `get_tier_options()` function
- [ ] Add to `/calculate/equipment` endpoint
- [ ] Write tests

#### Equipment Frontend
- [ ] Create `src/components/equipment/EquipmentCard.tsx`
- [ ] Create `src/components/equipment/TierComparison.tsx`
- [ ] Add equipment step to Duculator wizard
- [ ] Create Equipment admin page

#### Pricing Engine
- [ ] Create `app/services/pricing_engine.py`:
  - [ ] `calculate_materials()` function
  - [ ] `calculate_labor()` function
  - [ ] `calculate_total_price()` function
  - [ ] `generate_line_items()` function
- [ ] Add to `/calculate/pricing` endpoint
- [ ] Write tests

#### Pricing Frontend
- [ ] Create `src/components/jobs/PriceBreakdown.tsx`
- [ ] Create `src/components/jobs/LineItemEditor.tsx`
- [ ] Add pricing step to Duculator wizard
- [ ] Create Settings > Pricing page

### Sprint 3 (Week 5-6): Customers & Jobs

#### Customer API
- [ ] Create `app/models/customer.py`
- [ ] Create `app/services/geocoding_service.py` (Mapbox)
- [ ] Create `app/api/v1/customers.py`:
  - [ ] GET `/customers`
  - [ ] GET `/customers/{id}`
  - [ ] POST `/customers`
  - [ ] PUT `/customers/{id}`
  - [ ] DELETE `/customers/{id}`
- [ ] Write tests

#### Customer Frontend
- [ ] Create `src/components/customers/CustomerCard.tsx`
- [ ] Create `src/components/customers/CustomerForm.tsx`
- [ ] Create `src/components/customers/CustomerSearch.tsx`
- [ ] Create `src/pages/Customers.tsx`
- [ ] Create `src/pages/CustomerDetail.tsx`
- [ ] Add customer step to Duculator wizard

#### Job API
- [ ] Create `app/models/job.py`
- [ ] Create job number generator
- [ ] Create `app/api/v1/jobs.py`:
  - [ ] GET `/jobs`
  - [ ] GET `/jobs/{id}`
  - [ ] POST `/jobs`
  - [ ] PUT `/jobs/{id}`
  - [ ] PATCH `/jobs/{id}/status`
- [ ] Write tests

#### Job Frontend
- [ ] Create `src/components/jobs/JobCard.tsx`
- [ ] Create `src/components/jobs/StatusBadge.tsx`
- [ ] Create `src/components/jobs/JobForm.tsx`
- [ ] Create `src/pages/Jobs.tsx`
- [ ] Create `src/pages/JobDetail.tsx`
- [ ] Add review step to Duculator wizard
- [ ] Connect create job flow

#### Quote Generation
- [ ] Create `app/services/quote_generator.py`
- [ ] Create quote PDF template (Jinja2)
- [ ] Add GET `/jobs/{id}/quote.pdf` endpoint
- [ ] Add POST `/jobs/{id}/send-quote` endpoint
- [ ] Add download/email buttons to JobDetail

#### Dashboard
- [ ] Create `src/pages/Dashboard.tsx`
- [ ] Add stats cards
- [ ] Add upcoming jobs list
- [ ] Add recent quotes list

---

## 1.7 Claude Code Prompts

Use these prompts to build each piece:

### Prompt 1: Project Setup
```
Create a new FastAPI + React monorepo for an HVAC contractor platform called "TheWorx".

Backend requirements:
- FastAPI with async MongoDB (motor)
- Pydantic v2 for models
- JWT authentication with access/refresh tokens
- Project structure as specified in the README

Frontend requirements:
- Vite + React 18 + TypeScript
- Tailwind CSS
- Axios for API calls
- React Router for navigation

Create:
1. docker-compose.yml with MongoDB
2. Backend project structure
3. Frontend project structure
4. Basic configuration files
5. .env.example
```

### Prompt 2: Authentication
```
Implement authentication for TheWorx:

Backend:
- User model (email, password_hash, company_id, role, timestamps)
- Company model (name, phone, address, settings, subscription)
- JWT tokens (access: 30min, refresh: 7 days)
- Password hashing with bcrypt
- Endpoints: POST /register, POST /login, POST /refresh, GET /me

Frontend:
- AuthContext with login/logout/register functions
- useAuth hook
- Login page (email, password)
- Register page (company name, email, password, name, phone)
- Protected route wrapper
- Token storage and auto-refresh
```

### Prompt 3: Duculator Core
```
Build the Duculator load calculator for TheWorx:

Backend:
- Climate zone data (JSON) with humidity, design temp by zip prefix
- Load calculation:
  - Base: 25 BTU per sq ft
  - Humidity adjustment: >70% = 1.1x, >80% = 1.15x
  - Sun exposure: shady=0.9, partial=1.0, full=1.15
  - Occupancy: +400 BTU per person over 2
  - Ceiling: +4% per foot over 8ft
  - Insulation: poor=1.15, average=1.0, good=0.9
  - Windows: +5 BTU per sq ft of window area
- Duct sizing:
  - Outlets: tons × 4
  - Return: 20x20 (≤2.5T), 20x25 (≤4T), 25x25 (>4T)
  - Trunk: 10x18 (≤2.5T), 12x20 (≤4T), 14x24 (>4T)
  - Branch: 6" (≤3T), 7" (>3T)
- Round tons to nearest 0.5

Frontend:
- Multi-step wizard form
- Property input form with all fields
- Real-time zip code → region lookup
- Results display with BTU, tons, CFM, outlets
- Duct sizing summary
```

### Prompt 4: Equipment Matcher
```
Build the equipment matching system:

Backend:
- Equipment model with brand, model, tier, tons, seer, cfm, cost, warranty
- Seed data for Amana (good), American Standard (better), Trane (best)
- Tons: 1.5, 2, 2.5, 3, 3.5, 4, 5
- Match equipment by tons
- Return good/better/best options

Frontend:
- Three-column equipment comparison
- Equipment cards with brand, model, SEER, warranty
- "Best Value" badge on better tier
- Select button to choose tier
```

### Prompt 5: Pricing Engine
```
Build the job pricing engine:

Backend:
- Company settings for labor rates and margins
- Materials calculator:
  - Line set: $180 + (tons × $20)
  - Refrigerant: tons × $45
  - Electrical: $250
  - Thermostat: $85
  - Pad: $65
  - Ductwork: outlets × $120
  - Misc: $150
- Labor calculator:
  - Hours: 6 + (tons × 1.5)
  - Cost: hours × (install_rate + helper_rate)
- Pricing assembly:
  - Equipment + Materials + Labor = Subtotal
  - Overhead = Subtotal × overhead_percentage
  - Profit = Subtotal × profit_percentage
  - Total = Subtotal + Overhead + Profit
  - Margin = Profit / Total × 100

Frontend:
- Price breakdown component
- Line item editor (add/remove/edit)
- Margin indicator
- Settings page for rates
```

### Prompt 6: Customers
```
Build customer management:

Backend:
- Customer model with name, contact, address, location, job stats
- Mapbox geocoding for address → coordinates
- Search by name, phone, or address
- Pagination

Frontend:
- Customer list with search
- Customer cards
- Customer form (create/edit)
- Address autocomplete
- Customer detail page with job history
```

### Prompt 7: Jobs
```
Build job management:

Backend:
- Job model with all fields (property, load, equipment, pricing, schedule)
- Auto-generate job number: JOB-{YEAR}-{SEQUENCE}
- Status workflow: draft → quoted → approved → scheduled → in_progress → complete → invoiced → paid
- CRUD endpoints
- Status transition endpoint

Frontend:
- Jobs list with status filter tabs
- Job cards with status badge
- Job detail page with all info
- Status change buttons
- Edit capability
```

### Prompt 8: Quote PDF
```
Build quote PDF generation:

Backend:
- Jinja2 template for quote
- Company branding (logo, name, contact)
- Customer information
- System specifications
- Line items table
- Terms and conditions
- WeasyPrint for PDF generation
- Endpoint to download PDF
- Endpoint to email PDF to customer

Frontend:
- Download PDF button
- Send Quote button with email input
```

---

## 1.8 Test Scenarios

### Authentication
1. Register new company → creates company + owner user
2. Login with valid credentials → returns tokens
3. Access protected route without token → 401
4. Access protected route with valid token → success
5. Refresh expired access token → new access token

### Duculator
1. Enter 2400 sqft, 36830 zip → ~42,000 BTU, 3.5 ton
2. Change sun exposure to full → load increases
3. Increase occupancy → load increases
4. Select good insulation → load decreases

### Equipment
1. Request 3.5 ton equipment → returns 3 options
2. Each tier has correct brand and warranty
3. SEER increases with tier

### Pricing
1. Select equipment → generates line items
2. Change labor rate → total updates
3. Change profit percentage → margin updates
4. Edit line item → total recalculates

### Jobs
1. Complete wizard → creates job in draft
2. Mark as quoted → status changes
3. Mark as approved → status changes
4. Generate PDF → valid PDF downloads

---

## 1.9 Files to Create

```
backend/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── database.py
│   ├── api/
│   │   ├── __init__.py
│   │   ├── deps.py
│   │   └── v1/
│   │       ├── __init__.py
│   │       ├── router.py
│   │       ├── auth.py
│   │       ├── companies.py
│   │       ├── customers.py
│   │       ├── jobs.py
│   │       ├── equipment.py
│   │       └── calculate.py
│   ├── models/
│   │   ├── __init__.py
│   │   ├── base.py
│   │   ├── user.py
│   │   ├── company.py
│   │   ├── customer.py
│   │   ├── job.py
│   │   └── equipment.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── auth_service.py
│   │   ├── load_calculator.py
│   │   ├── equipment_matcher.py
│   │   ├── pricing_engine.py
│   │   ├── quote_generator.py
│   │   └── geocoding_service.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── security.py
│   │   ├── exceptions.py
│   │   └── constants.py
│   ├── data/
│   │   ├── climate_zones.json
│   │   └── equipment_seed.json
│   └── templates/
│       └── quote.html
├── tests/
│   ├── __init__.py
│   ├── conftest.py
│   ├── test_auth.py
│   ├── test_calculator.py
│   └── test_jobs.py
├── requirements.txt
├── Dockerfile
└── railway.toml

frontend/
├── src/
│   ├── main.tsx
│   ├── App.tsx
│   ├── index.css
│   ├── api/
│   │   ├── client.ts
│   │   ├── auth.ts
│   │   ├── customers.ts
│   │   ├── jobs.ts
│   │   ├── equipment.ts
│   │   └── calculate.ts
│   ├── components/
│   │   ├── ui/
│   │   │   ├── Button.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Modal.tsx
│   │   │   ├── Select.tsx
│   │   │   ├── Badge.tsx
│   │   │   └── Toast.tsx
│   │   ├── layout/
│   │   │   ├── Layout.tsx
│   │   │   ├── Sidebar.tsx
│   │   │   └── Header.tsx
│   │   ├── duculator/
│   │   │   ├── PropertyForm.tsx
│   │   │   ├── LoadResults.tsx
│   │   │   └── DuctSizing.tsx
│   │   ├── equipment/
│   │   │   ├── EquipmentCard.tsx
│   │   │   └── TierComparison.tsx
│   │   ├── jobs/
│   │   │   ├── JobCard.tsx
│   │   │   ├── JobForm.tsx
│   │   │   ├── JobDetail.tsx
│   │   │   ├── LineItemEditor.tsx
│   │   │   ├── PriceBreakdown.tsx
│   │   │   └── StatusBadge.tsx
│   │   └── customers/
│   │       ├── CustomerCard.tsx
│   │       ├── CustomerForm.tsx
│   │       └── CustomerSearch.tsx
│   ├── pages/
│   │   ├── Login.tsx
│   │   ├── Register.tsx
│   │   ├── Dashboard.tsx
│   │   ├── Duculator.tsx
│   │   ├── Jobs.tsx
│   │   ├── JobDetail.tsx
│   │   ├── Customers.tsx
│   │   ├── CustomerDetail.tsx
│   │   ├── Equipment.tsx
│   │   └── Settings.tsx
│   ├── hooks/
│   │   ├── useAuth.ts
│   │   ├── useJobs.ts
│   │   ├── useCustomers.ts
│   │   └── useEquipment.ts
│   ├── context/
│   │   ├── AuthContext.tsx
│   │   └── ToastContext.tsx
│   ├── utils/
│   │   ├── format.ts
│   │   └── validation.ts
│   └── types/
│       ├── index.ts
│       ├── auth.ts
│       ├── customer.ts
│       ├── job.ts
│       └── equipment.ts
├── index.html
├── package.json
├── tsconfig.json
├── tailwind.config.js
├── vite.config.ts
└── vercel.json
```

---

**End of Phase 1 Documentation**

Proceed to `PHASE2_DISPATCH.md` after completing Phase 1.
