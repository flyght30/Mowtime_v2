# Phase 7: Procurement & Inventory

**Duration:** 4 weeks
**Prerequisites:** Phase 6 complete
**Goal:** Equipment ordering, inventory tracking, purchase orders

---

## 7.1 Goals

By end of Phase 7, contractors can:
- Import distributor price lists
- See real-time equipment costs in estimates
- Track common parts inventory
- Get low-stock alerts
- Generate purchase orders from jobs
- Track actual vs estimated job costs

---

## 7.2 Features

### Distributor Pricing

**Sources:**
- Manual CSV upload (Baker's, Ferguson, etc.)
- Price list parser for common formats
- Scheduled refresh reminders

**Data Captured:**
- Equipment cost, MSRP
- Part numbers
- Availability status
- Lead times
- Price effective dates

### Inventory Tracking

**Track:**
- Common parts (filters, capacitors, contactors)
- Refrigerant stock
- Materials (line sets, wire, etc.)
- Consumables

**Features:**
- Current stock levels
- Reorder points
- Low stock alerts
- Stock adjustments
- Usage history

### Purchase Orders

**Flow:**
1. Job scheduled with equipment
2. Generate PO with required items
3. Approval workflow (optional)
4. Email PO to distributor
5. Mark as ordered → received
6. Update inventory

### Job Costing

**Compare:**
- Estimated materials vs actual
- Estimated labor vs actual
- Track profitability per job
- Roll up to reports

---

## 7.3 Database Models

### Distributor
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "name": str,                    # "Baker Distributing"
  "contact_name": str | None,
  "email": str,
  "phone": str,
  "account_number": str | None,
  "address": str,
  "price_list_updated": datetime | None,
  "is_active": bool,
  "created_at": datetime
}
```

### PriceListItem
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "distributor_id": ObjectId,
  
  "part_number": str,
  "description": str,
  "category": "equipment" | "parts" | "materials" | "refrigerant" | "other",
  
  "cost": float,
  "msrp": float | None,
  "unit": str,                    # "each", "foot", "lb"
  
  "brand": str | None,
  "model": str | None,
  
  "in_stock": bool,
  "lead_time_days": int | None,
  
  "effective_date": date,
  "expires_date": date | None,
  
  "updated_at": datetime
}
```

### InventoryItem
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  
  "name": str,
  "part_number": str | None,
  "category": str,
  "unit": str,
  
  "quantity_on_hand": float,
  "reorder_point": float,
  "reorder_quantity": float,
  
  "cost_per_unit": float,
  "last_cost": float,
  
  "location": str | None,          # "Warehouse", "Truck 1"
  
  "updated_at": datetime
}
```

### InventoryTransaction
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "item_id": ObjectId,
  
  "type": "adjustment" | "usage" | "received" | "transfer",
  "quantity": float,               # Positive or negative
  "job_id": ObjectId | None,
  "po_id": ObjectId | None,
  
  "notes": str | None,
  "user_id": ObjectId,
  "created_at": datetime
}
```

### PurchaseOrder
```python
{
  "_id": ObjectId,
  "company_id": ObjectId,
  "distributor_id": ObjectId,
  
  "po_number": str,                # "PO-2025-0001"
  "job_id": ObjectId | None,
  
  "status": "draft" | "pending_approval" | "approved" | "sent" | "partial" | "received" | "cancelled",
  
  "items": [
    {
      "part_number": str,
      "description": str,
      "quantity": float,
      "unit_cost": float,
      "total": float
    }
  ],
  
  "subtotal": float,
  "tax": float,
  "total": float,
  
  "notes": str | None,
  "sent_at": datetime | None,
  "received_at": datetime | None,
  
  "created_by": ObjectId,
  "approved_by": ObjectId | None,
  "created_at": datetime,
  "updated_at": datetime
}
```

### JobCost (embedded in Job)
```python
{
  "estimated": {
    "equipment": float,
    "materials": float,
    "labor_hours": float,
    "labor_cost": float,
    "total": float
  },
  "actual": {
    "equipment": float,
    "materials": float,
    "labor_hours": float,
    "labor_cost": float,
    "total": float,
    "parts_used": [
      { "item_id": ObjectId, "quantity": float, "cost": float }
    ]
  },
  "variance": {
    "equipment": float,
    "materials": float,
    "labor": float,
    "total": float,
    "percentage": float
  }
}
```

---

## 7.4 API Endpoints

### Distributors

```
GET /api/v1/distributors
POST /api/v1/distributors
PUT /api/v1/distributors/{id}
DELETE /api/v1/distributors/{id}

POST /api/v1/distributors/{id}/upload-pricelist
Request: multipart/form-data with CSV
Response: {
  "items_imported": 1250,
  "items_updated": 340,
  "items_skipped": 5,
  "errors": [...]
}
```

### Price List

```
GET /api/v1/pricelist
Query: ?distributor_id=...&category=equipment&search=carrier
Response: {
  "items": [...],
  "total": 45
}

GET /api/v1/pricelist/search
Query: ?q=24ACC636&brand=Carrier
Response: Matching items across distributors
```

### Inventory

```
GET /api/v1/inventory
Query: ?category=parts&low_stock=true
Response: {
  "items": [...],
  "low_stock_count": 5
}

POST /api/v1/inventory
Request: { "name": "35/5 MFD Capacitor", ... }
Response: Created item

PUT /api/v1/inventory/{id}
Request: Partial update
Response: Updated item

POST /api/v1/inventory/{id}/adjust
Request: {
  "quantity": -2,
  "reason": "Used on job",
  "job_id": "..."
}
Response: { "new_quantity": 15 }

GET /api/v1/inventory/alerts
Response: {
  "low_stock": [...],
  "out_of_stock": [...]
}
```

### Purchase Orders

```
GET /api/v1/purchase-orders
Query: ?status=sent
Response: { "items": [...] }

GET /api/v1/purchase-orders/{id}
Response: Full PO with items

POST /api/v1/purchase-orders
Request: {
  "distributor_id": "...",
  "job_id": "...",
  "items": [...]
}
Response: Created PO

PUT /api/v1/purchase-orders/{id}
Request: Update items or notes
Response: Updated PO

POST /api/v1/purchase-orders/{id}/approve
Response: Approved PO

POST /api/v1/purchase-orders/{id}/send
Response: { "sent": true, "email_id": "..." }

POST /api/v1/purchase-orders/{id}/receive
Request: {
  "items_received": [
    { "part_number": "...", "quantity": 1 }
  ]
}
Response: Updated PO and inventory
```

### Job Costing

```
GET /api/v1/jobs/{id}/costing
Response: {
  "estimated": { ... },
  "actual": { ... },
  "variance": { ... }
}

POST /api/v1/jobs/{id}/costing/actual
Request: {
  "labor_hours": 7.5,
  "parts_used": [
    { "item_id": "...", "quantity": 1 }
  ]
}
Response: Updated costing with variance
```

---

## 7.5 Wireframes

### Inventory List
```
┌────────────────────────────────────────────────────────────────────────┐
│  Inventory                                            [+ Add Item]    │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  [All] [Parts] [Materials] [Refrigerant]       🔍 Search    [⚠️ 5]    │
│                                                                        │
│  ⚠️ Low Stock Alerts                                                   │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ 35/5 MFD Capacitor          On Hand: 2    Reorder: 10         │   │
│  │ R-410A Refrigerant          On Hand: 15   Reorder: 25 lbs     │   │
│  │ 30A Disconnect              On Hand: 1    Reorder: 5          │   │
│  │                                           [Create PO →]        │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  All Items                                                             │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ Item                    │ Category │ On Hand │ Reorder │ Value │   │
│  ├─────────────────────────┼──────────┼─────────┼─────────┼───────┤   │
│  │ 35/5 MFD Capacitor      │ Parts    │ ⚠️ 2    │ 10      │ $30   │   │
│  │ 40/5 MFD Capacitor      │ Parts    │ 8       │ 10      │ $120  │   │
│  │ Single Pole Contactor   │ Parts    │ 12      │ 10      │ $180  │   │
│  │ Line Set 3/8 x 3/4 (ft) │ Material │ 150     │ 100     │ $450  │   │
│  │ R-410A (lbs)            │ Refrig.  │ ⚠️ 15   │ 25      │ $675  │   │
│  │ 14-2 Wire (ft)          │ Material │ 200     │ 100     │ $80   │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  Total Inventory Value: $12,450                                        │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Purchase Order
```
┌────────────────────────────────────────────────────────────────────────┐
│  ← Back                                               PO-2025-0015    │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  Distributor: Baker Distributing            Status: ● SENT            │
│  Created: Jan 22, 2025                      Sent: Jan 22, 2025        │
│  Job: JOB-2025-0045 (John Smith Install)                              │
│                                                                        │
│  ─────────────────────────────────────────────────────────────────    │
│                                                                        │
│  Items                                                                 │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ Part #        │ Description              │ Qty │ Unit   │ Total│   │
│  ├───────────────┼──────────────────────────┼─────┼────────┼──────┤   │
│  │ 24ACC636A003  │ Am Std Silver 15 3.5T    │ 1   │ $5,400 │$5,400│   │
│  │ LS-3830       │ Line Set 3/8x3/4 30ft    │ 1   │ $180   │ $180 │   │
│  │ NEST-T3007ES  │ Nest Thermostat          │ 1   │ $85    │ $85  │   │
│  │ CP-35/5       │ 35/5 MFD Capacitor       │ 2   │ $15    │ $30  │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│                                             Subtotal:      $5,695     │
│                                             Tax:           $456       │
│                                             Total:         $6,151     │
│                                                                        │
│  Notes:                                                                │
│  Deliver to job site: 123 Main St, Auburn. Call Mike (555-111-2222)   │
│  when 30 min out.                                                      │
│                                                                        │
│  ─────────────────────────────────────────────────────────────────    │
│                                                                        │
│  [Download PDF]  [Email Again]  [Mark Received]                       │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Job Costing View
```
┌────────────────────────────────────────────────────────────────────────┐
│  Job Costing - JOB-2025-0045                                          │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  John Smith • 123 Main St • Install 3.5T                              │
│                                                                        │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │                   │ Estimated  │ Actual    │ Variance          │   │
│  ├───────────────────┼────────────┼───────────┼───────────────────┤   │
│  │ Equipment         │ $5,400     │ $5,400    │ $0        0%      │   │
│  │ Materials         │ $1,850     │ $1,920    │ +$70      +3.8%   │   │
│  │ Labor (hrs)       │ 6.0        │ 7.5       │ +1.5      +25%    │   │
│  │ Labor ($)         │ $1,240     │ $1,550    │ +$310     +25%    │   │
│  ├───────────────────┼────────────┼───────────┼───────────────────┤   │
│  │ Total Cost        │ $8,490     │ $8,870    │ +$380     +4.5%   │   │
│  │ Customer Price    │ $11,462    │ $11,462   │                   │   │
│  │ Gross Profit      │ $2,972     │ $2,592    │ -$380             │   │
│  │ Margin            │ 25.9%      │ 22.6%     │ -3.3%             │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│  Variance Notes:                                                       │
│  - Extra labor: Replaced corroded disconnect box (unplanned)          │
│  - Extra materials: Disconnect box + wire                             │
│                                                                        │
│  Parts Used                                                            │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │ Item                       │ Qty │ Cost   │ From        │      │   │
│  │ Line Set 30ft              │ 1   │ $180   │ PO-2025-15  │      │   │
│  │ R-410A                     │ 4lb │ $180   │ Inventory   │      │   │
│  │ Disconnect Box 30A         │ 1   │ $45    │ Inventory   │      │   │
│  │ 10-2 Wire                  │ 15ft│ $25    │ Inventory   │      │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Price List Upload
```
┌─────────────────────────────────────────────────────────────────┐
│  Upload Price List                                       [✕]    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Distributor: [Baker Distributing            ▼]                 │
│                                                                 │
│  ─────────────────────────────────────────────────────────────  │
│                                                                 │
│  Upload CSV File                                                │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                                                         │   │
│  │         📄 Drop CSV file here or click to browse        │   │
│  │                                                         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Expected Columns:                                              │
│  part_number, description, cost, msrp, brand, model, category   │
│                                                                 │
│  [Download Template]                                            │
│                                                                 │
│  ─────────────────────────────────────────────────────────────  │
│                                                                 │
│  Previous Uploads                                               │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Jan 15, 2025 • 1,250 items imported                     │   │
│  │ Dec 1, 2024 • 1,180 items imported                      │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│                                       [Cancel] [Upload]         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 7.6 Implementation Checklist

### Sprint 17-18 (Week 31-34): Full Implementation

#### Distributor Management
- [ ] Distributor CRUD endpoints
- [ ] CSV upload endpoint
- [ ] CSV parser (flexible column mapping)
- [ ] Price list storage
- [ ] Distributor list page
- [ ] Upload modal

#### Inventory System
- [ ] Inventory item model
- [ ] Transaction logging
- [ ] CRUD endpoints
- [ ] Stock adjustment endpoint
- [ ] Low stock calculation
- [ ] Alert notifications
- [ ] Inventory list page
- [ ] Stock adjustment modal

#### Purchase Orders
- [ ] PO number generator
- [ ] PO CRUD endpoints
- [ ] Approval workflow (optional)
- [ ] Email send integration
- [ ] Receive items flow
- [ ] Inventory update on receive
- [ ] PO list and detail pages
- [ ] PDF generation

#### Job Costing
- [ ] Actual cost tracking
- [ ] Variance calculation
- [ ] Parts usage from inventory
- [ ] Labor hours from job
- [ ] Costing display on job detail
- [ ] Cost variance reports

---

## 7.7 Files to Create

```
backend/
├── app/
│   ├── api/v1/
│   │   ├── distributors.py     # NEW
│   │   ├── pricelist.py        # NEW
│   │   ├── inventory.py        # NEW
│   │   └── purchase_orders.py  # NEW
│   ├── models/
│   │   ├── distributor.py      # NEW
│   │   ├── pricelist.py        # NEW
│   │   ├── inventory.py        # NEW
│   │   └── purchase_order.py   # NEW
│   └── services/
│       ├── pricelist_parser.py # NEW
│       └── costing_service.py  # NEW

frontend/
├── src/
│   ├── components/
│   │   ├── inventory/
│   │   │   ├── InventoryList.tsx       # NEW
│   │   │   ├── InventoryForm.tsx       # NEW
│   │   │   ├── StockAdjustment.tsx     # NEW
│   │   │   └── LowStockAlert.tsx       # NEW
│   │   └── procurement/
│   │       ├── POList.tsx              # NEW
│   │       ├── PODetail.tsx            # NEW
│   │       ├── POForm.tsx              # NEW
│   │       └── PricelistUpload.tsx     # NEW
│   └── pages/
│       ├── Inventory.tsx               # NEW
│       ├── PurchaseOrders.tsx          # NEW
│       └── Distributors.tsx            # NEW
```

---

**End of Phase 7 Documentation**

Proceed to `PHASE8_INTEGRATIONS.md` after completing Phase 7.
